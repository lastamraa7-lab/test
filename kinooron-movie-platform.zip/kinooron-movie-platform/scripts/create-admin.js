'use strict';
// Admin accounts are created ONLY here (server-side CLI), never through the web UI or a client flag.
// Usage: ADMIN_USERNAME=... ADMIN_EMAIL=... ADMIN_PASSWORD=... npm run create-admin
const { load } = require('../src/config');
const { openDb, migrate } = require('../src/db');
const S = require('../src/security');

(async () => {
  const config = load();
  const { ADMIN_USERNAME: username, ADMIN_EMAIL: email, ADMIN_PASSWORD: password } = process.env;
  if (!username || !email || !password) { console.error('Set ADMIN_USERNAME, ADMIN_EMAIL and ADMIN_PASSWORD.'); process.exit(1); }
  const problem = S.passwordProblem(password, username);
  if (problem) { console.error(problem); process.exit(1); }
  const db = openDb(config.dbPath);
  migrate(db, config.migrationsDir);
  const now = new Date().toISOString();
  const hash = await S.hashPassword(password);
  const existing = db.prepare('SELECT id FROM users WHERE username_lc = ?').get(username.toLowerCase());
  if (existing) {
    db.prepare("UPDATE users SET role = 'admin', status = 'active', password_hash = ?, updated_at = ? WHERE id = ?").run(hash, now, existing.id);
    console.log(`User "${username}" promoted to admin and password reset.`);
  } else {
    db.prepare(`INSERT INTO users (public_id, username, username_lc, email, email_lc, password_hash, email_verified_at, role, terms_accepted_at, created_at, updated_at)
      VALUES (?,?,?,?,?,?,?, 'admin', ?,?,?)`).run(`usr_${S.randomToken(6)}`, username, username.toLowerCase(), email, email.toLowerCase(), hash, now, now, now, now);
    console.log(`Admin "${username}" created.`);
  }
  db.close();
})();
