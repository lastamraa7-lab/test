'use strict';
const { load } = require('../src/config');
const { openDb, migrate } = require('../src/db');
const config = load();
const db = openDb(config.dbPath);
const applied = migrate(db, config.migrationsDir);
console.log(applied.length ? `Applied: ${applied.join(', ')}` : 'Database is up to date.');
db.close();
