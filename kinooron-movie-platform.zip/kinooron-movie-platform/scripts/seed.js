'use strict';
// Development helper: activates the four VIP plans with SAMPLE prices. Refuses to run in production.
const { load } = require('../src/config');
const { openDb, migrate } = require('../src/db');
const config = load();
if (config.isProd) { console.error('Refusing to seed sample prices in production. Set real prices in /admin/plans.'); process.exit(1); }
const db = openDb(config.dbPath);
migrate(db, config.migrationsDir);
const prices = { 'vip-1': 9900, 'vip-3': 24900, 'vip-6': 44900, 'vip-12': 79900 };
for (const [code, price] of Object.entries(prices)) {
  db.prepare('UPDATE subscription_plans SET price_mnt = ?, active = 1, updated_at = ? WHERE code = ?').run(price, new Date().toISOString(), code);
}
console.log('Sample VIP plans activated (SAMPLE prices, change them in /admin/plans).');
db.close();
