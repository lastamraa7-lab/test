'use strict';
(function () {
  // Poster fallback: replace broken images (error events do not bubble, so capture).
  document.addEventListener('error', function (e) {
    var t = e.target;
    if (t && t.tagName === 'IMG' && !t.dataset.fallback) { t.dataset.fallback = '1'; t.src = '/img/no-poster.svg'; }
  }, true);
  document.addEventListener('load', function (e) { if (e.target && e.target.tagName === 'IMG') e.target.classList.add('loaded'); }, true);

  // Mobile navigation
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('site-nav');
  if (toggle && nav) toggle.addEventListener('click', function () {
    var open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });

  // Debounced search suggestions + clear button. Search text is never stored.
  var input = document.getElementById('q');
  var list = document.getElementById('suggest');
  var clear = document.querySelector('.search-clear');
  if (input && list) {
    var timer = null; var ctrl = null;
    var sync = function () { if (clear) clear.hidden = !input.value; };
    sync();
    var hide = function () { list.hidden = true; list.textContent = ''; };
    input.addEventListener('input', function () {
      sync();
      clearTimeout(timer);
      var q = input.value.trim();
      if (q.length < 2) { hide(); return; }
      timer = setTimeout(function () {
        if (ctrl) ctrl.abort();
        ctrl = new AbortController();
        fetch('/api/search?q=' + encodeURIComponent(q), { signal: ctrl.signal, headers: { accept: 'application/json' } })
          .then(function (r) { return r.json(); })
          .then(function (d) {
            list.textContent = '';
            if (!d.items || !d.items.length) { var li = document.createElement('li'); li.className = 'muted'; li.style.padding = '.6rem .7rem'; li.textContent = 'Үр дүн олдсонгүй'; list.appendChild(li); list.hidden = false; return; }
            d.items.forEach(function (m) {
              var li = document.createElement('li'); var a = document.createElement('a');
              a.href = '/title/' + encodeURIComponent(m.id);
              a.textContent = m.title + (m.year ? ' (' + m.year + ')' : '');
              li.appendChild(a); list.appendChild(li);
            });
            list.hidden = false;
          })
          .catch(function () { /* aborted or offline: keep the plain search form usable */ });
      }, 250);
    });
    if (clear) clear.addEventListener('click', function () { input.value = ''; sync(); hide(); input.focus(); });
    document.addEventListener('click', function (e) { if (!e.target.closest('.search')) hide(); });
    input.addEventListener('keydown', function (e) { if (e.key === 'Escape') hide(); });
  }

  // Player: resume position, report progress, show error state.
  var player = document.getElementById('player');
  if (player) {
    var csrf = (document.querySelector('meta[name=csrf-token]') || {}).content || '';
    var start = Number(player.dataset.start || 0);
    player.addEventListener('loadedmetadata', function () { if (start > 0 && start < player.duration) player.currentTime = start; });
    var last = 0;
    var send = function () {
      if (!csrf || !isFinite(player.duration)) return;
      fetch('/api/progress', { method: 'POST', credentials: 'same-origin', keepalive: true, headers: { 'content-type': 'application/json', 'x-csrf-token': csrf },
        body: JSON.stringify({ titleId: player.dataset.titleId, position: Math.floor(player.currentTime), duration: Math.floor(player.duration) }) }).catch(function () {});
    };
    player.addEventListener('timeupdate', function () { var n = Date.now(); if (n - last > 15000) { last = n; send(); } });
    player.addEventListener('pause', send);
    player.addEventListener('ended', send);
    player.addEventListener('error', function () { var el = document.getElementById('player-error'); if (el) el.hidden = false; });
  }
})();
