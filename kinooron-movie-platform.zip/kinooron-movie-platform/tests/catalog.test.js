'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startApp, Client, makeUser } = require('./helpers');
const { createTmdb, CatalogError } = require('../src/catalog/tmdb');
const { html, raw } = require('../src/views/html');
const { load } = require('../src/config');
const { addMonths } = require('../src/util');

let app;
before(async () => { app = await startApp(); });
after(async () => { await app.close(); });

test('sample data is clearly labelled and never presented as live', async () => {
  const c = new Client(app);
  const home = await c.get('/');
  assert.equal(home.status, 200);
  assert.match(home.text, /ЖИШЭЭ|жишээ/);
  assert.match((await c.get('/title/m3')).text, /ЖИШЭЭ|жишээ/);
  assert.match((await c.get('/poster/m3.svg')).text, /бодит зураг биш/);
});

test('search, filters, sorting and pagination', async () => {
  const c = new Client(app);
  const all = await c.get('/api/search?q=%D1%82%D1%8D%D0%BD%D0%B3%D1%8D%D1%80');
  assert.ok(JSON.parse(all.text).items.length > 0, 'known sample title is found');
  assert.equal(all.status, 200);
  const data = JSON.parse(all.text);
  assert.ok(Array.isArray(data.items));
  for (const r of data.items) assert.ok(r.id && r.title);
  assert.equal(JSON.parse((await c.get('/api/search?q=zzzzqqqq')).text).items.length, 0);
  assert.equal((await c.get('/api/search?q=a')).status, 200, 'short query handled');
  for (const q of ['genre=drama', 'type=series', 'sort=rating', 'sort=newest', 'sort=popular', 'year=2020', 'genre=bogus&sort=bogus&page=-5', 'page=9999']) assert.equal((await c.get(`/browse?${q}`)).status, 200, q);
  const page = await c.get('/browse?genre=bogus');
  assert.doesNotMatch(page.text, /undefined|NaN|\[object/);
});

test('user input is escaped (XSS) and security headers are present', async () => {
  const c = new Client(app);
  const r = await c.get('/browse?q=%3Cscript%3Ealert(1)%3C%2Fscript%3E');
  assert.doesNotMatch(r.text, /<script>alert\(1\)/);
  assert.equal(String(html`<b>${'<img src=x onerror=1>'}</b>`), '<b>&lt;img src=x onerror=1&gt;</b>');
  assert.equal(String(html`${raw('<i>ok</i>')}`), '<i>ok</i>');
  assert.match(r.headers.get('content-security-policy'), /script-src 'self'/);
  assert.equal(r.headers.get('x-frame-options'), 'DENY');
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  const api = await c.get('/api/search?q=%22%3E%3Csvg%3E');
  assert.match(api.headers.get('content-type'), /json/);
});

test('watchlist/progress APIs: auth required, input validated, per-user isolation', async () => {
  const anon = new Client(app);
  await anon.get('/');
  assert.equal((await anon.req('POST', '/api/progress', { json: { titleId: 'm3', position: 10, duration: 100 } })).status, 401);
  const a = await makeUser(app, 'viewerA'); const b = await makeUser(app, 'viewerB');
  await a.c.get('/title/m3');
  assert.equal((await a.c.post('/title/m3/list', { kind: 'favorite' })).status, 303);
  assert.equal((await a.c.post('/title/m3/list', { kind: 'bogus' })).status, 400);
  assert.equal((await a.c.post('/title/nope/list', { kind: 'watchlist' })).status, 404);
  assert.match((await a.c.get('/account')).text, /Сүүлчийн тэнгэр/);
  assert.doesNotMatch((await b.c.get('/account')).text, /Сүүлчийн тэнгэр/);
  // no authorized source yet -> progress is refused; with a source -> saved; malformed payloads rejected
  assert.equal((await a.c.req('POST', '/api/progress', { json: { titleId: 'm3', position: 12, duration: 100 } })).status, 403);
  app.db.prepare("INSERT OR REPLACE INTO title_settings (title_id, video_url, vip_only, updated_at) VALUES ('m3','https://media.example.test/m3.mp4',0,?)").run(new Date().toISOString());
  assert.equal((await a.c.req('POST', '/api/progress', { json: { titleId: 'm3', position: 12, duration: 100 } })).status, 200);
  assert.equal(app.db.prepare('SELECT position_seconds p FROM viewing_history WHERE user_id = ? AND title_id = ?').get(a.user.id, 'm3').p, 12);
  assert.equal((await b.c.req('POST', '/api/progress', { json: { titleId: '../etc', position: 1, duration: 1 } })).status, 400);
  // out-of-range numbers are clamped server-side, never stored raw
  await a.c.req('POST', '/api/progress', { json: { titleId: 'm3', position: -1, duration: 'x' } });
  const pr = app.db.prepare('SELECT position_seconds p, duration_seconds d FROM viewing_history WHERE user_id = ? AND title_id = ?').get(a.user.id, 'm3');
  assert.ok(pr.p >= 0 && pr.p <= 86400 && pr.d >= 0 && pr.d <= 86400);
});

const tmdbStub = (routes) => async (url) => {
  const u = new URL(url);
  const hit = routes[u.pathname.replace('/3', '')];
  if (!hit) return { ok: false, status: 404, json: async () => ({}) };
  if (typeof hit === 'number') return { ok: hit < 400, status: hit, json: async () => ({}) };
  return { ok: true, status: 200, json: async () => hit };
};

test('TMDB provider maps TMDB-shaped payloads (stubbed; NOT verified against the live API)', async () => {
  const movie = { id: 603, title: 'The Matrix', overview: 'o', poster_path: '/p.jpg', backdrop_path: '/b.jpg', release_date: '1999-03-30', vote_average: 8.2, popularity: 50, genres: [{ id: 878 }, { id: 28 }], runtime: 136, original_language: 'en' };
  const t = createTmdb({ apiKey: 'k', fetchImpl: tmdbStub({ '/movie/603': movie, '/discover/movie': { results: [movie], total_pages: 1, total_results: 1 }, '/trending/all/week': { results: [{ ...movie, media_type: 'movie' }] } }) });
  const item = await t.get('tmdb-movie-603');
  assert.ok(item);
  assert.equal(item.title, 'The Matrix');
  assert.equal(item.year, 1999);
  assert.ok(item.genres.includes('scifi'));
  assert.equal(item.sample, false);
  assert.equal(await t.get('tmdb-movie-999999'), null);
  assert.ok(t.attribution && /TMDB|TMDb|Movie Database/.test(t.attribution));
});

test('TMDB provider failures surface as typed errors (rate limit, bad key, outage)', async () => {
  for (const [status, kind] of [[429, 'rate'], [401, 'config'], [500, 'upstream']]) {
    const t = createTmdb({ apiKey: 'k', fetchImpl: tmdbStub({ '/movie/1': status }) });
    await assert.rejects(() => t.get('tmdb-movie-1'), (e) => e instanceof CatalogError && e.kind === kind);
  }
  const down = createTmdb({ apiKey: 'k', fetchImpl: async () => { throw new Error('ECONNREFUSED'); } });
  await assert.rejects(() => down.get('tmdb-movie-1'), (e) => e.kind === 'timeout');
});

test('catalog outage degrades to an error page, not a crash', async () => {
  const bad = await startApp({}, { provider: { name: 'broken', sample: false, attribution: '',
    async home() { throw new CatalogError('timeout', 'down'); }, async list() { throw new CatalogError('timeout', 'down'); },
    async get() { throw new CatalogError('timeout', 'down'); }, async facets() { return {}; } } });
  try {
    const c = new Client(bad);
    for (const p of ['/', '/browse', '/title/x']) { const r = await c.get(p); assert.ok([502, 503].includes(r.status), `${p} ${r.status}`); assert.match(r.text, /<html/); }
    assert.equal((await c.get('/vip')).status, 200, 'unrelated pages keep working');
    assert.equal((await c.get('/healthz')).status, 200);
  } finally { await bad.close(); }
});

test('watch page shows a graceful empty state when no authorized source exists', async () => {
  const u = await makeUser(app, 'nosource');
  const r = await u.c.get('/watch/m4');
  assert.ok([200, 303, 404].includes(r.status));
  if (r.status === 200) assert.match(r.text, /эх сурвалж|Бичлэг/i);
});

test('config safety and util edge cases', () => {
  assert.throws(() => load({ NODE_ENV: 'production', MAIL_MODE: 'outbox' }), /development-only/);
  assert.equal(load({ NODE_ENV: 'production' }).cookieSecure, true);
  assert.equal(load({ NODE_ENV: 'production' }).mailMode, 'none');
  assert.equal(addMonths(new Date('2026-01-31T00:00:00Z'), 1).toISOString().slice(0, 10), '2026-02-28');
  assert.equal(addMonths(new Date('2026-03-15T08:00:00Z'), 12).toISOString(), '2027-03-15T08:00:00.000Z');
});
