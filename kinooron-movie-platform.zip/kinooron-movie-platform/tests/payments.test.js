'use strict';
const { test, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { startApp, Client, multipartBody, makeUser, makeAdmin, vipOf, clock } = require('./helpers');
const { createTestProvider } = require('../src/payments/providers');
const P = require('../src/payments/service');

let app; let admin; let testProv;
const SECRET = 'unit-test-secret';
before(async () => {
  app = await startApp();
  admin = await makeAdmin(app);
  testProv = createTestProvider(SECRET);
  app.providers.register(testProv);
});
after(async () => { await app.close(); });
beforeEach(() => app.limiter.reset());

const plan = (code) => app.db.prepare('SELECT * FROM subscription_plans WHERE code = ?').get(code);
async function order(u, code = 'vip-1', extra = {}) {
  await u.c.get('/vip');
  const r = await u.c.post('/vip/checkout', { plan: String(plan(code).id), ...extra });
  assert.equal(r.status, 303, r.text.slice(0, 200));
  return app.db.prepare('SELECT * FROM payment_orders WHERE ref = ?').get(r.location.split('/').pop());
}
async function submit(u, o, ref = 'KHAN-12345') {
  const m = multipartBody({ _csrf: u.c.csrf, user_reference: ref });
  return u.c.req('POST', `/orders/${o.ref}/submit`, { multipart: m });
}

test('server-side price: client-supplied price/amount is ignored; inactive plans are refused', async () => {
  const u = await makeUser(app, 'buyer1');
  const o = await order(u, 'vip-3', { price_mnt: '1', amount: '1' });
  assert.equal(o.amount_mnt, 25000);
  assert.equal(o.status, 'CREATED');
  assert.equal(o.user_id, u.user.id);
  const page = await u.c.get(`/orders/${o.ref}`);
  assert.match(page.text, /25 000₮/);
  assert.match(page.text, new RegExp(o.ref));
  assert.match(page.text, /ТҮР ЗУРАГ|Төлбөрийн QR/);
  app.db.prepare('UPDATE subscription_plans SET active = 0 WHERE code = ?').run('vip-6');
  const r = await u.c.post('/vip/checkout', { plan: String(plan('vip-6').id) });
  assert.equal(r.status, 400);
  app.db.prepare('UPDATE subscription_plans SET active = 1 WHERE code = ?').run('vip-6');
});

test('pending / submitted orders never grant VIP', async () => {
  const u = await makeUser(app, 'buyer2');
  const o = await order(u);
  assert.equal(vipOf(app, u.user.id).active, false);
  const r = await submit(u, o);
  assert.equal(r.status, 303);
  const after = app.db.prepare('SELECT * FROM payment_orders WHERE id = ?').get(o.id);
  assert.equal(after.status, 'PENDING_REVIEW');
  assert.equal(vipOf(app, u.user.id).active, false);
  assert.equal((await submit(u, o)).status, 409, 'cannot resubmit');
});

test('forged, unsigned and unknown-provider callbacks never grant VIP', async () => {
  const u = await makeUser(app, 'buyer3');
  const o = await order(u);
  const body = JSON.stringify({ eventId: 'e-forged', orderRef: o.ref, providerTxnId: 'T1', amountMnt: o.amount_mnt, currency: 'MNT', state: 'PAID' });
  const anon = new Client(app);
  for (const [prov, headers] of [['khan_bank_official', {}], ['manual_khan_qr', {}], ['test_simulated', {}], ['test_simulated', { 'x-test-signature': 'deadbeef' }], ['test_simulated', { 'x-test-signature': testProv.sign(`${body} `) }]]) {
    const r = await fetch(`${app.base}/webhooks/${prov}`, { method: 'POST', body, headers: { 'content-type': 'application/json', ...headers } });
    assert.equal(r.status, 401, `${prov} ${JSON.stringify(headers)}`);
  }
  assert.equal((await fetch(`${app.base}/webhooks/unknown`, { method: 'POST', body })).status, 404);
  assert.equal(app.db.prepare('SELECT status FROM payment_orders WHERE id = ?').get(o.id).status, 'CREATED');
  assert.equal(vipOf(app, u.user.id).active, false);
  // The test provider cannot even be registered outside test mode.
  const prod = require('../src/app');
  assert.throws(() => { const a = prod.createApp({ NODE_ENV: 'development', DATA_DIR: app.dir + '-x', MAIL_MODE: 'none' }); try { a.providers.register(createTestProvider('x')); } finally { a.db.close(); } }, /only available when NODE_ENV=test/);
});

test('a genuinely authenticated provider confirmation grants VIP exactly once; duplicates and mismatches are safe', async () => {
  const u = await makeUser(app, 'buyer4');
  const o = await order(u, 'vip-3');
  app.db.prepare('UPDATE payment_orders SET provider = ? WHERE id = ?').run('test_simulated', o.id); // order created via the (test-only) automatic provider
  const send = async (evt, sign = true) => {
    const body = JSON.stringify(evt);
    return fetch(`${app.base}/webhooks/test_simulated`, { method: 'POST', body, headers: { 'content-type': 'application/json', ...(sign ? { 'x-test-signature': testProv.sign(body) } : {}) } });
  };
  const evt = { eventId: 'e1', orderRef: o.ref, providerTxnId: 'TX-1', amountMnt: o.amount_mnt, currency: 'MNT', state: 'PAID' };
  // wrong amount: authenticated but must not grant
  assert.equal((await send({ ...evt, eventId: 'e0', amountMnt: 1 })).status, 200);
  assert.equal(vipOf(app, u.user.id).active, false);
  assert.equal((await send(evt)).status, 200);
  // an event for an order that belongs to a different provider is ignored
  const other = await order(u, 'vip-1');
  assert.equal((await send({ ...evt, eventId: 'e-other', orderRef: other.ref, providerTxnId: 'TX-9', amountMnt: other.amount_mnt })).status, 200);
  assert.equal(app.db.prepare('SELECT status FROM payment_orders WHERE id = ?').get(other.id).status, 'CREATED');
  const first = vipOf(app, u.user.id);
  assert.equal(first.active, true);
  assert.equal((await send(evt)).status, 200, 'replayed event acknowledged');
  assert.equal((await send({ ...evt, eventId: 'e2' })).status, 200, 'same txn, new event id');
  assert.equal(vipOf(app, u.user.id).endsAt, first.endsAt, 'no second activation');
  assert.equal(app.db.prepare('SELECT COUNT(*) c FROM subscriptions WHERE user_id = ?').get(u.user.id).c, 1);
  assert.equal(app.db.prepare('SELECT status FROM payment_orders WHERE id = ?').get(o.id).status, 'PAID');
  const t = app.db.prepare('SELECT * FROM payment_transactions WHERE order_id = ?').all(o.id);
  assert.equal(t.length, 1);
  assert.equal(t[0].verification_method, 'provider_webhook');
  assert.ok(Math.abs(new Date(first.endsAt) - new Date(first.startsAt) - 89 * 86400000) < 4 * 86400000, '~3 months');
});

test('manual review: admin approval grants VIP once, with audit trail and safeguards', async () => {
  const u = await makeUser(app, 'buyer5');
  const o = await order(u, 'vip-1');
  await submit(u, o, 'BANK-777');
  const detail = await admin.c.get(`/admin/orders/${o.ref}`);
  assert.equal(detail.status, 200);
  const good = { bank_txn_ref: 'KB-0001', amount_mnt: String(o.amount_mnt), reason: 'Хаан банкны хуулгаас шалгав', confirm: 'on' };
  assert.equal((await admin.c.post(`/admin/orders/${o.ref}/approve`, { ...good, confirm: '' })).status, 422, 'confirmation required');
  assert.equal((await admin.c.post(`/admin/orders/${o.ref}/approve`, { ...good, amount_mnt: '5' })).status, 422, 'amount must match');
  assert.equal((await admin.c.post(`/admin/orders/${o.ref}/approve`, { ...good, reason: 'x' })).status, 422, 'reason required');
  assert.equal(vipOf(app, u.user.id).active, false);
  assert.equal((await admin.c.post(`/admin/orders/${o.ref}/approve`, good)).status, 303);
  const v = vipOf(app, u.user.id);
  assert.equal(v.active, true);
  await admin.c.post(`/admin/orders/${o.ref}/approve`, good); // double click
  assert.equal(vipOf(app, u.user.id).endsAt, v.endsAt);
  assert.equal(app.db.prepare('SELECT COUNT(*) c FROM subscriptions WHERE user_id = ?').get(u.user.id).c, 1);
  const o2 = app.db.prepare('SELECT * FROM payment_orders WHERE id = ?').get(o.id);
  assert.equal(o2.reviewed_by, admin.user.id);
  assert.equal(o2.bank_txn_ref, 'KB-0001');
  const log = app.db.prepare("SELECT * FROM admin_audit_logs WHERE action = 'payment.approve' AND target_id = ?").all(o.ref);
  assert.equal(log.length, 1);
  assert.match(log[0].reason, /хуулгаас/);
});

test('a bank transaction reference cannot be reused; rejection keeps VIP off; admins cannot approve their own orders', async () => {
  const a = await makeUser(app, 'buyer6');
  const b = await makeUser(app, 'buyer7');
  const oa = await order(a); const ob = await order(b);
  await submit(a, oa); await submit(b, ob);
  const form = (o, ref) => ({ bank_txn_ref: ref, amount_mnt: String(o.amount_mnt), reason: 'Банкны бичлэгээр шалгав', confirm: 'on' });
  assert.equal((await admin.c.post(`/admin/orders/${oa.ref}/approve`, form(oa, 'KB-DUP'))).status, 303);
  assert.equal((await admin.c.post(`/admin/orders/${ob.ref}/approve`, form(ob, 'KB-DUP'))).status, 409);
  assert.equal(vipOf(app, b.user.id).active, false);
  assert.equal((await admin.c.post(`/admin/orders/${ob.ref}/reject`, { reason: 'Банкинд гүйлгээ олдсонгүй' })).status, 303);
  assert.equal(app.db.prepare('SELECT status FROM payment_orders WHERE id = ?').get(ob.id).status, 'REJECTED');
  assert.equal(vipOf(app, b.user.id).active, false);
  // self-approval
  const own = await order({ c: admin.c, user: admin.user });
  await submit({ c: admin.c }, own);
  assert.equal((await admin.c.post(`/admin/orders/${own.ref}/approve`, form(own, 'KB-SELF'))).status, 403);
});

test('renewal extends from the existing expiry; expired VIP loses VIP-only access', async () => {
  const u = await makeUser(app, 'buyer8');
  app.db.prepare("INSERT INTO title_settings (title_id, video_url, vip_only, updated_at) VALUES ('m2','https://media.example.test/m2.mp4',1,?)").run(new Date().toISOString());
  assert.match((await u.c.get('/watch/m2')).location, /\/vip/, 'non-VIP redirected');
  assert.equal((await new Client(app).get('/watch/m2')).status, 303, 'anonymous redirected');
  const o1 = await order(u, 'vip-1'); await submit(u, o1);
  await admin.c.post(`/admin/orders/${o1.ref}/approve`, { bank_txn_ref: 'KB-R1', amount_mnt: String(o1.amount_mnt), reason: 'Банкны бичлэгээр шалгав', confirm: 'on' });
  const first = vipOf(app, u.user.id);
  const watch = await u.c.get('/watch/m2');
  assert.equal(watch.status, 200);
  assert.match(watch.text, /media\.example\.test\/m2\.mp4/);
  const o2 = await order(u, 'vip-1'); await submit(u, o2);
  await admin.c.post(`/admin/orders/${o2.ref}/approve`, { bank_txn_ref: 'KB-R2', amount_mnt: String(o2.amount_mnt), reason: 'Банкны бичлэгээр шалгав', confirm: 'on' });
  const second = vipOf(app, u.user.id);
  assert.ok(second.endsAt > first.endsAt);
  assert.equal(app.db.prepare('SELECT starts_at FROM subscriptions WHERE user_id = ? ORDER BY id DESC').get(u.user.id).starts_at, first.endsAt, 'starts when previous ends');
  clock.t = new Date(new Date(second.endsAt).getTime() + 1000);
  try {
    assert.equal(vipOf(app, u.user.id).active, false);
    assert.match((await u.c.get('/watch/m2')).location || 'login', /\/vip|\/login/, 'expired -> no access');
  } finally { clock.t = new Date('2026-10-25T10:00:00.000Z'); }
});

test('data isolation (IDOR) and admin authorization', async () => {
  const a = await makeUser(app, 'owner1');
  const b = await makeUser(app, 'intruder1');
  const o = await order(a);
  assert.equal((await b.c.get(`/orders/${o.ref}`)).status, 404);
  assert.equal((await b.c.get(`/orders/${o.ref}/receipt`)).status, 404);
  assert.equal((await b.c.post(`/orders/${o.ref}/submit`, { user_reference: 'ABC123' })).status, 404);
  assert.doesNotMatch((await b.c.get('/account')).text, new RegExp(o.ref));
  for (const p of ['/admin', '/admin/users', '/admin/orders', '/admin/plans', '/admin/audit', `/admin/orders/${o.ref}`]) {
    assert.equal((await b.c.get(p)).status, 404, p);
    assert.equal((await new Client(app).get(p)).status, 404, `${p} anonymous`);
  }
  assert.equal((await b.c.post(`/admin/orders/${o.ref}/approve`, { bank_txn_ref: 'X-1', amount_mnt: String(o.amount_mnt), reason: 'self approve try', confirm: 'on' })).status, 404);
  assert.equal(app.db.prepare('SELECT status FROM payment_orders WHERE id = ?').get(o.id).status, 'CREATED');
  // role cannot be escalated via profile/registration fields
  const c = new Client(app); await c.get('/register');
  await c.post('/register', { username: 'sneaky', email: 's@example.test', password: 'Sain-nuuts-ug-2026', password2: 'Sain-nuuts-ug-2026', terms: 'on', role: 'admin' });
  assert.equal(app.db.prepare("SELECT role FROM users WHERE username_lc = 'sneaky'").get().role, 'user');
});

test('receipt upload: only real images, size capped, stored outside public dir, owner/admin access only', async () => {
  const u = await makeUser(app, 'uploader');
  const o1 = await order(u);
  const bad = multipartBody({ _csrf: u.c.csrf, user_reference: 'REF-1234' }, { field: 'receipt', name: 'x.png', type: 'image/png', data: Buffer.from('<script>alert(1)</script>') });
  assert.equal((await u.c.req('POST', `/orders/${o1.ref}/submit`, { multipart: bad })).status, 422);
  assert.equal(app.db.prepare('SELECT status FROM payment_orders WHERE id = ?').get(o1.id).status, 'CREATED');
  const big = multipartBody({ _csrf: u.c.csrf, user_reference: 'REF-1234' }, { field: 'receipt', name: 'x.png', type: 'image/png', data: Buffer.alloc(3 * 1024 * 1024, 1) });
  assert.equal((await u.c.req('POST', `/orders/${o1.ref}/submit`, { multipart: big })).status, 413);
  const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(64, 7)]);
  const ok = multipartBody({ _csrf: u.c.csrf, user_reference: 'REF-1234' }, { field: 'receipt', name: '../../evil.php', type: 'text/html', data: png });
  assert.equal((await u.c.req('POST', `/orders/${o1.ref}/submit`, { multipart: ok })).status, 303);
  const row = app.db.prepare('SELECT * FROM payment_orders WHERE id = ?').get(o1.id);
  assert.equal(row.receipt_mime, 'image/png');
  assert.match(row.receipt_file, /^[\w-]+\.png$/);
  const mine = await fetch(`${app.base}/orders/${o1.ref}/receipt`, { headers: { cookie: Object.entries(u.c.jar).map(([k, v]) => `${k}=${v}`).join('; ') } });
  assert.equal(mine.status, 200);
  assert.equal(mine.headers.get('content-type'), 'image/png');
  assert.equal((await new Client(app).get(`/orders/${o1.ref}/receipt`)).status, 303);
  assert.equal((await admin.c.get(`/orders/${o1.ref}/receipt`)).status, 200);
});

test('expired unpaid orders expire; plan price changes do not alter existing orders', async () => {
  const u = await makeUser(app, 'expirer');
  const o = await order(u, 'vip-12');
  app.db.prepare('UPDATE subscription_plans SET price_mnt = 99999 WHERE code = ?').run('vip-12');
  assert.equal(app.db.prepare('SELECT amount_mnt FROM payment_orders WHERE id = ?').get(o.id).amount_mnt, 80000);
  app.db.prepare('UPDATE subscription_plans SET price_mnt = 80000 WHERE code = ?').run('vip-12');
  clock.t = new Date(clock.t.getTime() + 3 * 3600000);
  try {
    assert.match((await u.c.get(`/orders/${o.ref}`)).text, /Хугацаа дууссан/);
    assert.equal(app.db.prepare('SELECT status FROM payment_orders WHERE id = ?').get(o.id).status, 'EXPIRED');
    assert.equal((await submit(u, o)).status, 409);
  } finally { clock.t = new Date('2026-10-25T10:00:00.000Z'); }
});

test('admin: plan pricing, manual grant/revoke with mandatory reason, audit log, user disable', async () => {
  const u = await makeUser(app, 'managed');
  const p = plan('vip-6');
  assert.equal((await admin.c.post(`/admin/plans/${p.id}`, { price_mnt: '-5', active: 'on', reason: 'жишээ шалтгаан' })).status, 422);
  assert.equal((await admin.c.post(`/admin/plans/${p.id}`, { price_mnt: '46000', active: 'on', reason: '' })).status, 422);
  assert.equal((await admin.c.post(`/admin/plans/${p.id}`, { price_mnt: '46000', active: 'on', reason: 'Үнийн шинэчлэл' })).status, 303);
  assert.equal(plan('vip-6').price_mnt, 46000);
  assert.equal((await admin.c.post(`/admin/users/${u.user.id}/vip`, { action: 'grant', plan: String(p.id), reason: '' })).status, 422);
  assert.equal(vipOf(app, u.user.id).active, false);
  assert.equal((await admin.c.post(`/admin/users/${u.user.id}/vip`, { action: 'grant', plan: String(p.id), reason: 'Урамшуулал олгов' })).status, 303);
  assert.equal(vipOf(app, u.user.id).active, true);
  assert.equal((await admin.c.post(`/admin/users/${u.user.id}/vip`, { action: 'revoke', reason: 'Буруугаар олгосон' })).status, 303);
  assert.equal(vipOf(app, u.user.id).active, false);
  const actions = app.db.prepare('SELECT action FROM admin_audit_logs ORDER BY id').all().map((r) => r.action);
  for (const a of ['plan.update', 'vip.grant', 'vip.revoke']) assert.ok(actions.includes(a), a);
  assert.equal((await admin.c.post(`/admin/users/${u.user.id}/status`, { status: 'disabled', reason: 'Дүрэм зөрчсөн' })).status, 303);
  assert.equal((await u.c.get('/account')).status, 303, 'disabled users are signed out');
  const re = new Client(app); await re.get('/login');
  assert.equal((await re.post('/login', { identifier: 'managed', password: 'Sain-nuuts-ug-2026' })).status, 401);
  assert.equal((await admin.c.post(`/admin/users/${admin.user.id}/status`, { status: 'disabled', reason: 'өөрийгөө хаах' })).status, 403);
  for (const pth of ['/admin', '/admin/orders', '/admin/users', `/admin/users/${u.user.id}`, '/admin/plans', '/admin/titles', '/admin/audit', '/admin/orders?status=PENDING_REVIEW']) assert.equal((await admin.c.get(pth)).status, 200, pth);
});

test('reconciliation invariant: every PAID order has a transaction and subscription', () => {
  const paid = app.db.prepare("SELECT id FROM payment_orders WHERE status = 'PAID'").all();
  assert.ok(paid.length >= 3);
  for (const { id } of paid) {
    assert.equal(app.db.prepare('SELECT COUNT(*) c FROM payment_transactions WHERE order_id = ?').get(id).c, 1);
    assert.equal(app.db.prepare('SELECT COUNT(*) c FROM subscriptions WHERE order_id = ?').get(id).c, 1);
  }
  assert.equal(app.db.prepare("SELECT COUNT(*) c FROM subscriptions WHERE source = 'payment' AND order_id NOT IN (SELECT id FROM payment_orders WHERE status = 'PAID')").get().c, 0);
  assert.equal(P.expireStale(app.db, new Date(clock.t)) >= 0, true);
});
