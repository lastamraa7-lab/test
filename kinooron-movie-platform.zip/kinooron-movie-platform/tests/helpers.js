'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createApp } = require('../src/app');
const S = require('../src/security');

const clock = { t: new Date('2026-10-25T10:00:00.000Z') };

async function startApp(extraEnv = {}, direct = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kino-test-'));
  const app = createApp({ NODE_ENV: 'test', DATA_DIR: dir, ...extraEnv }, { now: () => new Date(clock.t), ...direct });
  const port = await app.listen(0);
  app.base = `http://127.0.0.1:${port}`;
  app.dir = dir;
  // Plans are seeded inactive by the migration; activate with known test prices.
  const prices = { 'vip-1': 10000, 'vip-3': 25000, 'vip-6': 45000, 'vip-12': 80000 };
  for (const [code, price] of Object.entries(prices)) app.db.prepare('UPDATE subscription_plans SET price_mnt = ?, active = 1 WHERE code = ?').run(price, code);
  return app;
}

class Client {
  constructor(app) { this.app = app; this.jar = {}; this.csrf = ''; }
  async req(method, url, { form, json, multipart, headers = {} } = {}) {
    const h = { ...headers };
    const cookie = Object.entries(this.jar).map(([k, v]) => `${k}=${v}`).join('; ');
    if (cookie) h.cookie = cookie;
    let body;
    if (form) { h['content-type'] = 'application/x-www-form-urlencoded'; body = new URLSearchParams({ _csrf: this.csrf, ...form }).toString(); }
    if (json) { h['content-type'] = 'application/json'; h['x-csrf-token'] = this.csrf; body = JSON.stringify(json); }
    if (multipart) { h['content-type'] = `multipart/form-data; boundary=${multipart.boundary}`; body = multipart.body; }
    const res = await fetch(this.app.base + url, { method, headers: h, body, redirect: 'manual' });
    for (const c of res.headers.getSetCookie()) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i); const v = pair.slice(i + 1);
      if (v === '' || /Max-Age=0/i.test(c)) delete this.jar[k]; else this.jar[k] = v;
    }
    const text = await res.text();
    const m = /<meta name="csrf-token" content="([^"]*)"/.exec(text);
    if (m && m[1]) this.csrf = m[1];
    return { status: res.status, text, headers: res.headers, location: res.headers.get('location'), setCookie: res.headers.getSetCookie() };
  }
  get(url, o) { return this.req('GET', url, o); }
  post(url, form, o = {}) { return this.req('POST', url, { form, ...o }); }
  async follow(r) { return r.location ? this.get(r.location) : r; }
}

function multipartBody(fields, file) {
  const boundary = `----t${Math.random().toString(16).slice(2)}`;
  const parts = [];
  for (const [k, v] of Object.entries(fields)) parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`));
  if (file) parts.push(Buffer.concat([Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${file.field}"; filename="${file.name}"\r\nContent-Type: ${file.type}\r\n\r\n`), file.data, Buffer.from('\r\n')]));
  parts.push(Buffer.from(`--${boundary}--\r\n`));
  return { boundary, body: Buffer.concat(parts) };
}

const PW = 'Sain-nuuts-ug-2026';
let counter = 0;

/** Register through the real HTTP flow and mark the email verified directly in the DB. */
async function makeUser(app, name) {
  const c = new Client(app);
  counter += 1;
  const username = name || `user${counter}`;
  await c.get('/register');
  const r = await c.post('/register', { username, email: `${username}@example.test`, password: PW, password2: PW, terms: 'on' });
  if (r.status !== 303) throw new Error(`register failed ${r.status}: ${r.text.slice(0, 300)}`);
  app.db.prepare('UPDATE users SET email_verified_at = ? WHERE username_lc = ?').run(new Date().toISOString(), username.toLowerCase());
  const user = app.db.prepare('SELECT * FROM users WHERE username_lc = ?').get(username.toLowerCase());
  await c.get('/account');
  return { c, user, username };
}

async function makeAdmin(app, name = 'boss') {
  const hash = await S.hashPassword(PW);
  const now = new Date().toISOString();
  app.db.prepare(`INSERT INTO users (public_id, username, username_lc, email, email_lc, password_hash, email_verified_at, role, terms_accepted_at, created_at, updated_at)
    VALUES (?,?,?,?,?,?,?, 'admin', ?,?,?)`).run(`usr_${S.randomToken(5)}`, name, name, `${name}@example.test`, `${name}@example.test`, hash, now, now, now, now);
  const c = new Client(app);
  await c.get('/login');
  const r = await c.post('/login', { identifier: name, password: PW, next: '/' });
  if (r.status !== 303) throw new Error('admin login failed');
  await c.get('/admin');
  return { c, user: app.db.prepare('SELECT * FROM users WHERE username_lc = ?').get(name) };
}

const vipOf = (app, userId) => require('../src/subscriptions').getVipStatus(app.db, userId, new Date(clock.t));

module.exports = { startApp, Client, multipartBody, makeUser, makeAdmin, vipOf, clock, PW };
