'use strict';
const { test, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { startApp, Client, makeUser, PW } = require('./helpers');

let app;
before(async () => { app = await startApp(); });
after(async () => { await app.close(); });
beforeEach(() => app.limiter.reset());

test('registration validates input, hashes passwords and blocks duplicates', async () => {
  const c = new Client(app);
  await c.get('/register');
  let r = await c.post('/register', { username: 'a!', email: 'bad', password: 'short', password2: 'x' });
  assert.equal(r.status, 400);
  assert.match(r.text, /Нэвтрэх нэр 3–24/);
  r = await c.post('/register', { username: 'amaraa', email: 'amaraa@example.test', password: PW, password2: PW });
  assert.equal(r.status, 400, 'terms must be accepted');
  r = await c.post('/register', { username: 'amaraa', email: 'amaraa@example.test', password: PW, password2: PW, terms: 'on' });
  assert.equal(r.status, 303);
  const row = app.db.prepare('SELECT password_hash FROM users WHERE username_lc = ?').get('amaraa');
  assert.ok(!row.password_hash.includes(PW));
  assert.match(row.password_hash, /^(scrypt|argon2id)\$/);
  const cookie = r.setCookie.find((x) => x.startsWith('sid='));
  assert.match(cookie, /HttpOnly/);
  assert.match(cookie, /SameSite=Lax/);
  const dup = new Client(app);
  await dup.get('/register');
  r = await dup.post('/register', { username: 'AMARAA', email: 'other@example.test', password: PW, password2: PW, terms: 'on' });
  assert.equal(r.status, 400);
  assert.match(r.text, /аль хэдийн бүртгэлтэй/);
  r = await dup.post('/register', { username: 'someone', email: 'Amaraa@Example.test', password: PW, password2: PW, terms: 'on' });
  assert.equal(r.status, 400);
});

test('login, logout, session persistence across devices and wrong-password handling', async () => {
  const { username } = await makeUser(app, 'persist');
  const dev1 = new Client(app);
  await dev1.get('/login');
  let r = await dev1.post('/login', { identifier: username, password: 'wrong-password-1' });
  assert.equal(r.status, 401);
  r = await dev1.post('/login', { identifier: username, password: PW });
  assert.equal(r.status, 303);
  // add watchlist item, then logout and log in from another "device"
  await dev1.get('/title/m3');
  r = await dev1.post('/title/m3/list', { kind: 'watchlist' });
  assert.equal(r.status, 303);
  r = await dev1.post('/logout', {});
  assert.equal(r.status, 303);
  assert.equal((await dev1.get('/account')).status, 303, 'account requires login after logout');
  const dev2 = new Client(app);
  await dev2.get('/login');
  await dev2.post('/login', { identifier: `${username}@example.test`, password: PW });
  const acct = await dev2.get('/account');
  assert.equal(acct.status, 200);
  assert.match(acct.text, /Сүүлчийн тэнгэр/, 'watchlist persists');
});

test('login is rate limited', async () => {
  const c = new Client(app);
  await c.get('/login');
  let last;
  for (let i = 0; i < 10; i += 1) last = await c.post('/login', { identifier: 'ghost-user', password: 'nope-nope-nope' });
  assert.equal(last.status, 429);
});

test('email verification and password recovery', async () => {
  const { c, username, user } = await makeUser(app, 'recover');
  app.db.prepare('UPDATE users SET email_verified_at = NULL WHERE id = ?').run(user.id);
  const mail = app.db.prepare("SELECT body FROM outbox WHERE to_email = ? AND subject LIKE '%баталгаажуулах%' ORDER BY id DESC").get(`${username}@example.test`);
  assert.ok(mail, 'verification mail queued');
  const link = /(\/verify-email\?token=[\w-]+)/.exec(mail.body)[1];
  await c.get(link);
  assert.ok(app.db.prepare('SELECT email_verified_at FROM users WHERE id = ?').get(user.id).email_verified_at);
  assert.match((await c.get(link)).location || '', /account|login/, 'token is single-use');

  const anon = new Client(app);
  await anon.get('/forgot');
  let r = await anon.post('/forgot', { email: 'nobody@example.test' });
  assert.equal(r.status, 303);
  await anon.post('/forgot', { email: `${username}@example.test` });
  const reset = app.db.prepare("SELECT body FROM outbox WHERE subject LIKE '%нууц үг сэргээх%' ORDER BY id DESC").get();
  const rl = /(\/reset\?token=[\w-]+)/.exec(reset.body)[1];
  const page = await anon.get(rl);
  assert.equal(page.status, 200);
  const token = /name="token" value="([^"]+)"/.exec(page.text)[1];
  const NEW = 'Shine-nuuts-ug-77';
  r = await anon.post('/reset', { token, password: NEW, password2: NEW });
  assert.equal(r.status, 303);
  assert.equal((await c.get('/account')).status, 303, 'old sessions are signed out after reset');
  r = await anon.post('/reset', { token, password: 'Another-pass-123', password2: 'Another-pass-123' });
  assert.match(r.location, /forgot/, 'reset token cannot be reused');
  const fresh = new Client(app);
  await fresh.get('/login');
  assert.equal((await fresh.post('/login', { identifier: username, password: PW })).status, 401);
  assert.equal((await fresh.post('/login', { identifier: username, password: NEW })).status, 303);
});

test('CSRF protection and cross-origin POST rejection', async () => {
  const { c } = await makeUser(app, 'csrfuser');
  const saved = c.csrf;
  c.csrf = 'forged';
  assert.equal((await c.post('/logout', {})).status, 403);
  c.csrf = saved;
  assert.equal((await c.post('/logout', {}, { headers: { origin: 'https://evil.example' } })).status, 403);
  assert.equal((await c.get('/account')).status, 200, 'still signed in after rejected attempts');
});

test('private pages require login; direct open and refresh of public routes work', async () => {
  const c = new Client(app);
  for (const p of ['/account', '/vip/checkout']) {
    const r = await c.get(p);
    assert.ok([303, 405].includes(r.status), `${p} -> ${r.status}`);
  }
  for (const p of ['/', '/browse', '/browse?page=2', '/title/m5', '/vip', '/terms', '/privacy', '/help', '/contact', '/login', '/register', '/forgot']) {
    assert.equal((await c.get(p)).status, 200, p);
    assert.equal((await c.get(p)).status, 200, `${p} (refresh)`);
  }
  assert.equal((await c.get('/title/does-not-exist')).status, 404);
  assert.equal((await c.get('/nope')).status, 404);
});
