-- 001_init.sql  Core schema. All timestamps are UTC ISO-8601 strings.

CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  public_id TEXT NOT NULL UNIQUE,
  username TEXT NOT NULL,
  username_lc TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL,
  email_lc TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  email_verified_at TEXT,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','disabled')),
  terms_accepted_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- token_hash is sha256(cookie token); the raw token is never stored.
CREATE TABLE sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  csrf_token TEXT NOT NULL,
  flash TEXT,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL
);
CREATE INDEX idx_sessions_user ON sessions(user_id);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);

CREATE TABLE email_tokens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('verify','reset')),
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  used_at TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_email_tokens_user ON email_tokens(user_id, kind);

-- Development-only mail sink (MAIL_MODE=outbox). Never enabled in production.
CREATE TABLE outbox (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  to_email TEXT NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE subscription_plans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  months INTEGER NOT NULL CHECK (months > 0),
  price_mnt INTEGER NOT NULL CHECK (price_mnt > 0),
  active INTEGER NOT NULL DEFAULT 0 CHECK (active IN (0,1)),
  sort_order INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL
);

CREATE TABLE payment_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ref TEXT NOT NULL UNIQUE,
  user_id INTEGER NOT NULL REFERENCES users(id),
  plan_id INTEGER NOT NULL REFERENCES subscription_plans(id),
  plan_name TEXT NOT NULL,
  months INTEGER NOT NULL,
  amount_mnt INTEGER NOT NULL CHECK (amount_mnt > 0),
  currency TEXT NOT NULL DEFAULT 'MNT' CHECK (currency = 'MNT'),
  provider TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('CREATED','PENDING_REVIEW','PAID','REJECTED','EXPIRED','FAILED','REFUNDED')),
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  submitted_at TEXT,
  user_reference TEXT,
  receipt_file TEXT,
  receipt_mime TEXT,
  reviewed_by INTEGER REFERENCES users(id),
  reviewed_at TEXT,
  review_reason TEXT,
  bank_txn_ref TEXT,
  paid_at TEXT
);
CREATE INDEX idx_orders_user ON payment_orders(user_id, created_at);
CREATE INDEX idx_orders_status ON payment_orders(status, created_at);
CREATE UNIQUE INDEX uq_orders_bank_txn_ref ON payment_orders(bank_txn_ref) WHERE bank_txn_ref IS NOT NULL;

CREATE TABLE subscriptions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  plan_id INTEGER REFERENCES subscription_plans(id),
  order_id INTEGER UNIQUE REFERENCES payment_orders(id), -- UNIQUE: one activation per paid order
  source TEXT NOT NULL CHECK (source IN ('payment','admin_grant')),
  starts_at TEXT NOT NULL,
  ends_at TEXT NOT NULL,
  revoked_at TEXT,
  revoked_reason TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_subscriptions_user ON subscriptions(user_id, ends_at);

CREATE TABLE payment_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES payment_orders(id),
  provider TEXT NOT NULL,
  provider_txn_id TEXT NOT NULL,
  amount_mnt INTEGER NOT NULL,
  currency TEXT NOT NULL,
  state TEXT NOT NULL,
  verification_method TEXT NOT NULL CHECK (verification_method IN ('manual_admin','provider_api','provider_webhook')),
  verified_by INTEGER REFERENCES users(id),
  verified_at TEXT NOT NULL,
  UNIQUE (provider, provider_txn_id)
);
CREATE INDEX idx_txn_order ON payment_transactions(order_id);

CREATE TABLE webhook_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  provider TEXT NOT NULL,
  event_id TEXT NOT NULL,
  received_at TEXT NOT NULL,
  signature_valid INTEGER NOT NULL,
  outcome TEXT NOT NULL,
  UNIQUE (provider, event_id)
);

CREATE TABLE user_watchlists (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title_id TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('watchlist','favorite')),
  created_at TEXT NOT NULL,
  PRIMARY KEY (user_id, title_id, kind)
);

CREATE TABLE viewing_history (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title_id TEXT NOT NULL,
  position_seconds INTEGER NOT NULL DEFAULT 0,
  duration_seconds INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (user_id, title_id)
);
CREATE INDEX idx_history_user ON viewing_history(user_id, updated_at);

-- Admin-managed rights data: only titles with an authorized source can be played.
CREATE TABLE title_settings (
  title_id TEXT PRIMARY KEY,
  video_url TEXT,
  subtitle_url TEXT,
  vip_only INTEGER NOT NULL DEFAULT 0 CHECK (vip_only IN (0,1)),
  updated_at TEXT NOT NULL
);

CREATE TABLE admin_audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  admin_id INTEGER NOT NULL REFERENCES users(id),
  action TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id TEXT NOT NULL,
  reason TEXT,
  details TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_audit_created ON admin_audit_logs(created_at);

-- Plans are created INACTIVE with placeholder prices. The owner must set the
-- real prices and activate them in /admin/plans before accepting payments.
INSERT INTO subscription_plans (code, name, months, price_mnt, active, sort_order, updated_at) VALUES
  ('vip-1',  '1 сарын VIP',  1,  1000, 0, 1, '2026-01-01T00:00:00.000Z'),
  ('vip-3',  '3 сарын VIP',  3,  2000, 0, 2, '2026-01-01T00:00:00.000Z'),
  ('vip-6',  '6 сарын VIP',  6,  3000, 0, 3, '2026-01-01T00:00:00.000Z'),
  ('vip-12', '12 сарын VIP', 12, 4000, 0, 4, '2026-01-01T00:00:00.000Z');
