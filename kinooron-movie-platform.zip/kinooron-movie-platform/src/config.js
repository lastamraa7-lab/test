'use strict';
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');

function loadDotEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    if (line.trim().startsWith('#')) continue;
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (!m) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (!(m[1] in process.env)) process.env[m[1]] = v;
  }
}

/** overrides: env-style string values (tests), plus an optional `direct` object merged last. */
function load(overrides = {}, direct = {}) {
  loadDotEnv(path.join(ROOT, '.env'));
  const e = { ...process.env, ...overrides };
  const env = e.NODE_ENV || 'development';
  const isProd = env === 'production';
  const dataDir = path.resolve(ROOT, e.DATA_DIR || 'data');
  const qrImage = e.KHAN_QR_IMAGE || '/img/khan-qr-placeholder.svg';
  const mailMode = e.MAIL_MODE || (isProd ? 'none' : 'outbox');
  if (isProd && mailMode === 'outbox') throw new Error('MAIL_MODE=outbox is development-only');
  return {
    root: ROOT,
    env,
    isProd,
    port: Number(e.PORT || 3000),
    siteName: e.SITE_NAME || 'Киноорон',
    baseUrl: (e.APP_BASE_URL || '').replace(/\/+$/, ''),
    dataDir,
    dbPath: e.DATABASE_PATH ? path.resolve(ROOT, e.DATABASE_PATH) : path.join(dataDir, 'app.sqlite'),
    uploadDir: path.join(dataDir, 'receipts'),
    publicDir: path.join(ROOT, 'public'),
    migrationsDir: path.join(ROOT, 'migrations'),
    sessionTtlDays: Number(e.SESSION_TTL_DAYS || 14),
    cookieSecure: e.COOKIE_SECURE ? e.COOKIE_SECURE === 'true' : isProd,
    trustProxy: e.TRUST_PROXY === 'true',
    tmdbApiKey: e.TMDB_API_KEY || '',
    qrImage,
    qrIsPlaceholder: qrImage === '/img/khan-qr-placeholder.svg',
    payeeLabel: e.PAYEE_LABEL || '',
    orderTtlMinutes: Number(e.ORDER_TTL_MINUTES || 120),
    mailMode,
    requireVerifiedEmailForPurchase: e.REQUIRE_VERIFIED_EMAIL_FOR_PURCHASE
      ? e.REQUIRE_VERIFIED_EMAIL_FOR_PURCHASE === 'true'
      : mailMode !== 'none',
    allowTestProvider: env === 'test',
    quiet: env === 'test',
    now: () => new Date(),
    ...direct,
  };
}

module.exports = { load };
