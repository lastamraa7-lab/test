'use strict';
const mock = require('./mock');
const { createTmdb } = require('./tmdb');

/** TMDB when a key is configured, otherwise the clearly labeled mock layer. */
function createCatalog(config, overrides = {}) {
  if (overrides.provider) return overrides.provider;
  if (config.tmdbApiKey) return createTmdb({ apiKey: config.tmdbApiKey, language: process.env.TMDB_LANGUAGE || 'en-US' });
  return mock;
}
module.exports = { createCatalog };
