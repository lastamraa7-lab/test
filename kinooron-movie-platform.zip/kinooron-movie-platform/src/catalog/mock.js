'use strict';
// CLEARLY LABELED SAMPLE DATA for development without a metadata API key.
// All titles are fictional. Ratings/popularity are invented and must never be shown as live data.
const { GENRES } = require('./genres');

const RAW = [
  ['Хилийн цаадах салхи', 2024, 'movie', 118, ['thriller', 'drama'], 7.4, 93],
  ['Алтан хадны нууц', 2023, 'movie', 126, ['action', 'drama'], 6.9, 71],
  ['Сүүлчийн тэнгэр', 2025, 'movie', 134, ['scifi', 'thriller'], 7.8, 98],
  ['Хөх шувууны дуу', 2022, 'movie', 94, ['animation', 'comedy'], 7.1, 64],
  ['Шөнийн мөрдөгч', 2024, 'series', 52, ['thriller', 'drama'], 8.1, 88],
  ['Эрдэнийн зам', 2021, 'movie', 112, ['drama', 'romance'], 6.7, 40],
  ['Тэнгэр рүү харсан хүү', 2023, 'movie', 101, ['animation', 'drama'], 7.9, 77],
  ['Аймгийн сүнс', 2024, 'movie', 97, ['horror'], 6.2, 82],
  ['Цагийн хаалга', 2025, 'movie', 129, ['scifi', 'action'], 7.3, 95],
  ['Хайрын хоёр улирал', 2022, 'series', 45, ['romance', 'comedy'], 7.0, 55],
  ['Говийн уралдаан', 2023, 'movie', 108, ['action', 'comedy'], 6.5, 60],
  ['Харанхуй тосгон', 2022, 'movie', 103, ['horror', 'thriller'], 6.8, 68],
  ['Од руу аялал', 2024, 'movie', 99, ['scifi', 'animation'], 7.6, 73],
  ['Бүгдийн нэрийн өмнөөс', 2021, 'movie', 121, ['drama'], 8.0, 35],
  ['Нүүдэлчин нар', 2025, 'series', 58, ['drama'], 8.3, 90],
  ['Гурван хулгайч', 2023, 'movie', 105, ['comedy', 'action'], 6.6, 58],
  ['Цасан цагаан гэрэл', 2022, 'movie', 110, ['romance', 'drama'], 7.2, 49],
  ['Дугуйтай Дулмаа', 2024, 'movie', 88, ['animation', 'comedy'], 7.5, 66],
  ['Сүүдрийн хөгжим', 2025, 'series', 47, ['thriller', 'horror'], 7.7, 86],
  ['Төмөр хот', 2023, 'movie', 131, ['scifi', 'action'], 7.0, 74],
  ['Хаврын захидал', 2021, 'movie', 96, ['romance'], 6.4, 30],
  ['Сүүлчийн галт тэрэг', 2024, 'movie', 115, ['thriller', 'drama'], 7.9, 80],
  ['Манханы хөвгүүд', 2022, 'series', 40, ['comedy', 'drama'], 7.4, 52],
  ['Тэнгэрийн хаяа', 2025, 'movie', 123, ['action', 'drama'], 7.1, 91],
];

const SYNOPSES = [
  'Туршилтын жишээ тайлбар: түүх хоёр найзын зам дээр эхэлж, хүлээгээгүй нууцтай золгоно.',
  'Туршилтын жишээ тайлбар: жижиг хотод болсон нэгэн хэрэг бүх оршин суугчдын амьдралыг өөрчилнө.',
  'Туршилтын жишээ тайлбар: гэр бүлийн нууц ил болж, гол дүр шийдвэр гаргахаас өөр аргагүй болно.',
];

const items = RAW.map(([title, year, type, runtime, genres, rating, popularity], i) => ({
  id: `m${i + 1}`,
  type,
  title,
  year,
  release_date: `${year}-0${(i % 9) + 1}-15`,
  runtime,
  genres,
  rating,
  popularity,
  weekly: (popularity * 7 + i * 13) % 100,
  synopsis: SYNOPSES[i % SYNOPSES.length],
  language: 'mn',
  country: 'MN',
  added_at: new Date(Date.UTC(2026, 8, 30) - i * 86400000 * 3).toISOString(),
  cast: [],
  director: null,
  trailer_url: null,
  posterUrl: `/poster/m${i + 1}.svg`,
  backdropUrl: `/poster/m${i + 1}.svg?w=backdrop`,
  sample: true,
  hue: (i * 47) % 360,
}));

const SORTS = {
  popularity: (a, b) => b.popularity - a.popularity,
  newest: (a, b) => (b.release_date < a.release_date ? -1 : b.release_date > a.release_date ? 1 : 0),
  rating: (a, b) => b.rating - a.rating,
};

const provider = {
  name: 'mock',
  isSample: true,
  attribution: null,

  async list({ q = '', genre = '', year = '', type = '', rating = 0, language = '', sort = 'popularity', page = 1, pageSize = 24 } = {}) {
    let r = items.slice();
    const needle = q.trim().toLowerCase();
    if (needle) {
      r = r.filter((m) => m.title.toLowerCase().includes(needle) || m.genres.some((g) => GENRES[g].toLowerCase().includes(needle)));
    }
    if (genre && GENRES[genre]) r = r.filter((m) => m.genres.includes(genre));
    if (year) r = r.filter((m) => String(m.year) === String(year));
    if (type === 'movie' || type === 'series') r = r.filter((m) => m.type === type);
    if (rating) r = r.filter((m) => m.rating >= Number(rating));
    if (language) r = r.filter((m) => m.language === language);
    r.sort(SORTS[sort] || SORTS.popularity);
    const total = r.length;
    const pages = Math.max(1, Math.ceil(total / pageSize));
    const p = Math.min(Math.max(1, page), pages);
    return { items: r.slice((p - 1) * pageSize, p * pageSize), total, page: p, pages };
  },

  async get(id) {
    const m = items.find((x) => x.id === id);
    if (!m) return null;
    const similar = items.filter((x) => x.id !== id && x.genres.some((g) => m.genres.includes(g))).slice(0, 8);
    return { ...m, similar };
  },

  async home() {
    const by = (key, n = 12, filter = () => true) => items.filter(filter).sort((a, b) => b[key] - a[key]).slice(0, n);
    const rows = [
      { key: 'trending', title: 'Тренд', items: by('popularity') },
      { key: 'weekly', title: 'Энэ долоо хоногийн алдартай', items: by('weekly') },
      { key: 'recent', title: 'Саяхан нэмэгдсэн', items: items.slice().sort((a, b) => (a.added_at < b.added_at ? 1 : -1)).slice(0, 12) },
      { key: 'top', title: 'Өндөр үнэлгээтэй', items: by('rating') },
      { key: 'series', title: 'Олон ангит кино', items: by('popularity', 12, (m) => m.type === 'series') },
    ];
    for (const [k, label] of Object.entries(GENRES)) {
      rows.push({ key: `genre-${k}`, title: label, genre: k, items: by('popularity', 12, (m) => m.genres.includes(k)) });
    }
    return { hero: by('popularity', 1)[0], rows };
  },

  async facets() {
    return { years: [...new Set(items.map((m) => m.year))].sort((a, b) => b - a), languages: [...new Set(items.map((m) => m.language))] };
  },
};

module.exports = provider;
