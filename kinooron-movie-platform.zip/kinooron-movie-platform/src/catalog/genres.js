'use strict';
// Canonical genre keys -> Mongolian labels.
const GENRES = {
  action: 'Экшн',
  drama: 'Драма',
  comedy: 'Инээдмийн',
  horror: 'Аймшиг',
  romance: 'Романтик',
  scifi: 'Шинжлэх ухааны уран зөгнөл',
  animation: 'Хүүхэлдэйн',
  thriller: 'Триллер',
};
const label = (k) => GENRES[k] || k;
module.exports = { GENRES, label };
