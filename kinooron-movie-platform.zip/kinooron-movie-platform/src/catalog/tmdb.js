'use strict';
// TMDB v3 metadata provider. Metadata only: TMDB does NOT grant streaming rights.
// NOTE: written against TMDB's public v3 API shape; NOT verified against the live API in the
// build environment (no network). Tests use a stubbed fetch with TMDB-shaped payloads.
const { GENRES } = require('./genres');

const BASE = 'https://api.themoviedb.org/3';
const IMG = 'https://image.tmdb.org/t/p';
const MOVIE_GENRE = { action: 28, drama: 18, comedy: 35, horror: 27, romance: 10749, scifi: 878, animation: 16, thriller: 53 };
const TV_GENRE = { action: 10759, drama: 18, comedy: 35, animation: 16, scifi: 10765 };
const REVERSE = {};
for (const [k, id] of Object.entries(MOVIE_GENRE)) REVERSE[id] = k;
for (const [k, id] of Object.entries(TV_GENRE)) REVERSE[id] = REVERSE[id] || k;

class CatalogError extends Error {
  constructor(kind, message) { super(message); this.kind = kind; }
}

function createTmdb({ apiKey, language = 'en-US', fetchImpl = globalThis.fetch, now = () => Date.now() }) {
  const cache = new Map();
  const TTL = 5 * 60 * 1000;

  async function call(path, params = {}) {
    const qs = new URLSearchParams({ language, ...params });
    const keyForCache = `${path}?${qs}`;
    const hit = cache.get(keyForCache);
    if (hit && now() - hit.t < TTL) return hit.v;
    qs.set('api_key', apiKey); // appended after the cache key so the secret is never used as a map key
    let res;
    try {
      res = await fetchImpl(`${BASE}${path}?${qs}`, { signal: AbortSignal.timeout(8000), headers: { accept: 'application/json' } });
    } catch {
      throw new CatalogError('timeout', 'Metadata provider unreachable');
    }
    if (res.status === 429) throw new CatalogError('rate', 'Metadata provider rate limit');
    if (res.status === 401) throw new CatalogError('config', 'Metadata provider rejected the API key');
    if (res.status === 404) return null;
    if (!res.ok) throw new CatalogError('upstream', `Metadata provider error ${res.status}`);
    const v = await res.json();
    if (cache.size > 500) cache.clear();
    cache.set(keyForCache, { v, t: now() });
    return v;
  }

  function normalize(r, kind) {
    const k = r.media_type === 'tv' ? 'tv' : r.media_type === 'movie' ? 'movie' : kind;
    const date = r.release_date || r.first_air_date || '';
    const genreIds = r.genre_ids || (r.genres || []).map((g) => g.id);
    return {
      id: `tmdb-${k}-${r.id}`,
      type: k === 'tv' ? 'series' : 'movie',
      title: r.title || r.name || '',
      year: date ? Number(date.slice(0, 4)) : null,
      release_date: date || null,
      synopsis: r.overview || '',
      rating: r.vote_count > 0 ? Math.round(r.vote_average * 10) / 10 : null,
      popularity: r.popularity || 0,
      genres: genreIds.map((id) => REVERSE[id]).filter(Boolean),
      language: r.original_language || null,
      posterUrl: r.poster_path ? `${IMG}/w500${r.poster_path}` : null,
      backdropUrl: r.backdrop_path ? `${IMG}/w1280${r.backdrop_path}` : null,
      sample: false,
    };
  }

  const SORT_MOVIE = { popularity: 'popularity.desc', newest: 'primary_release_date.desc', rating: 'vote_average.desc' };
  const SORT_TV = { popularity: 'popularity.desc', newest: 'first_air_date.desc', rating: 'vote_average.desc' };

  async function discover(kind, o) {
    const tv = kind === 'tv';
    const map = tv ? TV_GENRE : MOVIE_GENRE;
    if (o.genre && !map[o.genre]) return { results: [], total_pages: 1, total_results: 0 };
    const p = { page: String(o.page || 1), sort_by: (tv ? SORT_TV : SORT_MOVIE)[o.sort] || 'popularity.desc', include_adult: 'false' };
    if (o.genre) p.with_genres = String(map[o.genre]);
    if (o.year) p[tv ? 'first_air_date_year' : 'primary_release_year'] = String(o.year);
    if (o.rating) { p['vote_average.gte'] = String(o.rating); p['vote_count.gte'] = '100'; }
    if (o.sort === 'rating') p['vote_count.gte'] = '200';
    if (o.language) p.with_original_language = o.language;
    return (await call(`/discover/${kind}`, p)) || { results: [], total_pages: 1, total_results: 0 };
  }

  return {
    name: 'tmdb',
    isSample: false,
    attribution: 'This product uses the TMDB API but is not endorsed or certified by TMDB.',
    normalize,

    async list({ q = '', genre = '', year = '', type = '', rating = 0, language = '', sort = 'popularity', page = 1, pageSize = 20 } = {}) {
      let results = [];
      let pages = 1;
      let total = 0;
      if (q.trim()) {
        const d = await call('/search/multi', { query: q.trim(), page: String(page), include_adult: 'false' });
        results = (d?.results || [])
          .filter((r) => r.media_type === 'movie' || r.media_type === 'tv')
          .filter((r) => !type || (type === 'series') === (r.media_type === 'tv'))
          .map((r) => normalize(r, r.media_type));
        if (genre) results = results.filter((m) => m.genres.includes(genre));
        pages = d?.total_pages || 1;
        total = d?.total_results || results.length;
      } else {
        const kinds = type === 'series' ? ['tv'] : type === 'movie' ? ['movie'] : ['movie', 'tv'];
        const parts = await Promise.all(kinds.map((k) => discover(k, { genre, year, rating, language, sort, page }).then((d) => ({ k, d }))));
        for (const { k, d } of parts) {
          results.push(...d.results.map((r) => normalize(r, k)));
          pages = Math.max(pages, d.total_pages || 1);
          total += d.total_results || 0;
        }
        const cmp = { popularity: (a, b) => b.popularity - a.popularity, newest: (a, b) => String(b.release_date).localeCompare(String(a.release_date)), rating: (a, b) => (b.rating || 0) - (a.rating || 0) };
        results.sort(cmp[sort] || cmp.popularity);
      }
      return { items: results.slice(0, Math.max(pageSize, 20)), total, page, pages: Math.min(pages, 500) };
    },

    async get(id) {
      const m = /^tmdb-(movie|tv)-(\d+)$/.exec(id);
      if (!m) return null;
      const [, kind, num] = m;
      const d = await call(`/${kind}/${num}`, { append_to_response: 'credits,videos,recommendations' });
      if (!d) return null;
      const base = normalize({ ...d, genre_ids: undefined }, kind);
      const trailer = (d.videos?.results || []).find((v) => v.site === 'YouTube' && v.type === 'Trailer');
      const director = kind === 'movie'
        ? (d.credits?.crew || []).find((c) => c.job === 'Director')?.name || null
        : (d.created_by || [])[0]?.name || null;
      return {
        ...base,
        runtime: kind === 'movie' ? d.runtime || null : (d.episode_run_time || [])[0] || null,
        cast: (d.credits?.cast || []).slice(0, 10).map((c) => c.name),
        director,
        production: (d.production_companies || []).map((c) => c.name),
        trailer_url: trailer ? `https://www.youtube.com/watch?v=${encodeURIComponent(trailer.key)}` : null,
        similar: (d.recommendations?.results || []).slice(0, 8).map((r) => normalize(r, kind)),
      };
    },

    async home() {
      const jobs = [
        ['trending', 'Тренд', () => call('/trending/all/week'), 'mixed'],
        ['weekly', 'Энэ долоо хоногийн алдартай', () => call('/movie/popular'), 'movie'],
        ['recent', 'Саяхан нэмэгдсэн', () => call('/movie/now_playing'), 'movie'],
        ['top', 'Өндөр үнэлгээтэй', () => call('/movie/top_rated'), 'movie'],
        ['series', 'Олон ангит кино', () => call('/tv/popular'), 'tv'],
        ...Object.keys(GENRES).map((g) => [`genre-${g}`, GENRES[g], () => discover('movie', { genre: g, sort: 'popularity' }), 'movie', g]),
      ];
      const settled = await Promise.allSettled(jobs.map((j) => j[2]()));
      const rows = [];
      settled.forEach((s, i) => {
        if (s.status !== 'fulfilled' || !s.value) return;
        const [key, title, , kind, genre] = jobs[i];
        const items = (s.value.results || []).filter((r) => kind !== 'mixed' || r.media_type === 'movie' || r.media_type === 'tv').slice(0, 12).map((r) => normalize(r, kind === 'mixed' ? 'movie' : kind));
        if (items.length) rows.push({ key, title, genre, items });
      });
      if (!rows.length) throw new CatalogError('upstream', 'No catalog rows available');
      const hero = rows[0].items.find((m) => m.backdropUrl) || rows[0].items[0];
      return { hero, rows };
    },

    async facets() {
      const y = new Date(now()).getUTCFullYear();
      return { years: Array.from({ length: 40 }, (_, i) => y - i), languages: ['mn', 'en', 'ko', 'ja', 'zh', 'ru'] };
    },
  };
}

module.exports = { createTmdb, CatalogError };
