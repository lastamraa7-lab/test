'use strict';

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; this.expose = true; }
}

const iso = (d) => (d instanceof Date ? d : new Date(d)).toISOString();

/** Add calendar months in UTC, clamping the day (Jan 31 + 1 month = Feb 28/29). */
function addMonths(date, months) {
  const d = new Date(date);
  const day = d.getUTCDate();
  d.setUTCDate(1);
  d.setUTCMonth(d.getUTCMonth() + months);
  const last = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
  d.setUTCDate(Math.min(day, last));
  return d;
}

function intParam(v, def, min, max) {
  const n = Number.parseInt(v, 10);
  if (!Number.isFinite(n)) return def;
  return Math.min(max, Math.max(min, n));
}

const fmtMnt = (n) => `${Number(n).toLocaleString('en-US').replace(/,/g, ' ')}₮`;
const fmtDate = (s) => (s ? String(s).slice(0, 10) : '—');
const fmtDateTime = (s) => (s ? String(s).slice(0, 16).replace('T', ' ') + ' UTC' : '—');

/** Only allow same-site relative redirects. */
function safeNext(v) {
  if (typeof v !== 'string' || !v.startsWith('/') || v.startsWith('//') || v.includes('\\')) return '/';
  return v;
}

module.exports = { HttpError, iso, addMonths, intParam, fmtMnt, fmtDate, fmtDateTime, safeNext };
