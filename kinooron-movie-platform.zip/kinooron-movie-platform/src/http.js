'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { HttpError } = require('./util');
const { safeEqual } = require('./security');

const MIME = { '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8' };

function parseCookies(header) {
  const out = {};
  if (!header) return out;
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    const k = part.slice(0, i).trim();
    if (!k || k in out) continue;
    try { out[k] = decodeURIComponent(part.slice(i + 1).trim()); } catch { /* ignore malformed */ }
  }
  return out;
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const declared = Number(req.headers['content-length'] || 0);
    if (declared > limit) { reject(new HttpError(413, 'Хүсэлт хэт том байна.')); req.resume(); return; }
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new HttpError(413, 'Хүсэлт хэт том байна.')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

/** Minimal multipart/form-data parser (fields + file parts, held in memory under a hard size cap). */
function parseMultipart(buf, boundary) {
  const fields = {};
  const files = [];
  const delim = Buffer.from(`--${boundary}`);
  let pos = buf.indexOf(delim);
  while (pos !== -1) {
    const next = buf.indexOf(delim, pos + delim.length);
    if (next === -1) break;
    let part = buf.subarray(pos + delim.length, next);
    if (part[0] === 13 && part[1] === 10) part = part.subarray(2);
    if (part.length >= 2 && part[part.length - 2] === 13 && part[part.length - 1] === 10) part = part.subarray(0, part.length - 2);
    const sep = part.indexOf('\r\n\r\n');
    if (sep !== -1) {
      const head = part.subarray(0, sep).toString('utf8');
      const data = part.subarray(sep + 4);
      const name = /name="([^"]*)"/i.exec(head);
      const filename = /filename="([^"]*)"/i.exec(head);
      const ctype = /content-type:\s*([^\r\n;]+)/i.exec(head);
      if (name) {
        if (filename) files.push({ field: name[1], filename: filename[1], mime: ctype ? ctype[1].trim().toLowerCase() : '', data });
        else fields[name[1]] = data.toString('utf8');
      }
    }
    pos = next;
  }
  return { fields, files };
}

function createRouter() {
  const routes = [];
  const add = (method, pattern, handler, opts = {}) => {
    const keys = [];
    const re = new RegExp(`^${pattern.replace(/:([a-z]+)/gi, (_, k) => { keys.push(k); return '([^/]+)'; })}/?$`);
    routes.push({ method, re, keys, handler, opts });
  };
  const match = (method, pathname) => {
    let pathMatched = false;
    for (const r of routes) {
      const m = r.re.exec(pathname);
      if (!m) continue;
      pathMatched = true;
      if (r.method !== method) continue;
      const params = {};
      r.keys.forEach((k, i) => { try { params[k] = decodeURIComponent(m[i + 1]); } catch { params[k] = ''; } });
      return { route: r, params };
    }
    return { route: null, pathMatched };
  };
  return { get: (p, h, o) => add('GET', p, h, o), post: (p, h, o) => add('POST', p, h, o), match };
}

function serveStatic(config, pathname, res) {
  const rel = pathname.replace(/^\/+/, '');
  const full = path.resolve(config.publicDir, rel);
  if (!full.startsWith(config.publicDir + path.sep)) return false;
  const ext = path.extname(full).toLowerCase();
  if (!MIME[ext]) return false;
  let st;
  try { st = fs.statSync(full); } catch { return false; }
  if (!st.isFile()) return false;
  res.writeHead(200, { 'content-type': MIME[ext], 'content-length': st.size, 'cache-control': config.isProd ? 'public, max-age=86400' : 'no-cache', 'x-content-type-options': 'nosniff' });
  fs.createReadStream(full).pipe(res);
  return true;
}

function securityHeaders(config, extraImg = '') {
  const h = {
    'content-security-policy': `default-src 'self'; img-src 'self' data: ${extraImg}; media-src 'self' https:; script-src 'self'; style-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'`,
    'x-content-type-options': 'nosniff',
    'x-frame-options': 'DENY',
    'referrer-policy': 'same-origin',
    'permissions-policy': 'camera=(), microphone=(), geolocation=()',
    'cross-origin-opener-policy': 'same-origin',
  };
  if (config.cookieSecure) h['strict-transport-security'] = 'max-age=31536000; includeSubDomains';
  return h;
}

function clientIp(req, config) {
  if (config.trustProxy) {
    const xf = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (xf) return xf;
  }
  return req.socket.remoteAddress || 'unknown';
}

/** CSRF: the session-bound token must match, and a browser Origin header (if present) must be same-origin. */
function checkCsrf(ctx, supplied) {
  if (!ctx.session || !supplied || !safeEqual(supplied, ctx.session.csrf)) throw new HttpError(403, 'Хүсэлтийн баталгаажуулалт амжилтгүй боллоо. Хуудсаа шинэчлээд дахин оролдоно уу.');
  const origin = ctx.req.headers.origin;
  if (origin && origin !== 'null') {
    let host;
    try { host = new URL(origin).host; } catch { host = ''; }
    if (host !== ctx.req.headers.host) throw new HttpError(403, 'Хүсэлтийн эх сурвалж зөвшөөрөгдөөгүй байна.');
  }
}

module.exports = { parseCookies, readBody, parseMultipart, createRouter, serveStatic, securityHeaders, clientIp, checkCsrf };
