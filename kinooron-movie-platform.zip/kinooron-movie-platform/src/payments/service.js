'use strict';
const { tx, isUniqueError } = require('../db');
const { randomToken } = require('../security');
const { iso, HttpError } = require('../util');
const { extendSubscription } = require('../subscriptions');

const REF_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
function newRef() {
  const bytes = require('node:crypto').randomBytes(8);
  let s = '';
  for (const b of bytes) s += REF_ALPHABET[b % REF_ALPHABET.length];
  return `KO-${s}`;
}

function audit(db, now, adminId, action, targetType, targetId, reason, details) {
  db.prepare('INSERT INTO admin_audit_logs (admin_id, action, target_type, target_id, reason, details, created_at) VALUES (?,?,?,?,?,?,?)')
    .run(adminId, action, targetType, String(targetId), reason || null, details ? JSON.stringify(details) : null, iso(now));
}

function expireStale(db, now) {
  return db.prepare("UPDATE payment_orders SET status = 'EXPIRED' WHERE status = 'CREATED' AND expires_at <= ?").run(iso(now)).changes;
}

/** The price always comes from the database plan row, never from the client. */
function createOrder(db, config, providers, { userId, planId, now }) {
  return tx(db, () => {
    expireStale(db, now);
    const plan = db.prepare('SELECT * FROM subscription_plans WHERE id = ? AND active = 1').get(planId);
    if (!plan) throw new HttpError(400, 'Сонгосон багц олдсонгүй эсвэл идэвхгүй байна.');
    const existing = db.prepare("SELECT * FROM payment_orders WHERE user_id = ? AND plan_id = ? AND status = 'CREATED' AND amount_mnt = ? AND expires_at > ?")
      .get(userId, plan.id, plan.price_mnt, iso(now));
    if (existing) return existing;
    const open = db.prepare("SELECT COUNT(*) AS c FROM payment_orders WHERE user_id = ? AND status IN ('CREATED','PENDING_REVIEW')").get(userId).c;
    if (open >= 5) throw new HttpError(429, 'Хэт олон дуусаагүй захиалга байна. Эхлээд өмнөх захиалгаа дуусгана уу.');
    const provider = providers.default;
    for (let attempt = 0; attempt < 5; attempt += 1) {
      try {
        const info = db.prepare(
          `INSERT INTO payment_orders (ref, user_id, plan_id, plan_name, months, amount_mnt, currency, provider, status, created_at, expires_at)
           VALUES (?,?,?,?,?,?, 'MNT', ?, 'CREATED', ?, ?)`)
          .run(newRef(), userId, plan.id, plan.name, plan.months, plan.price_mnt, provider.name, iso(now),
            iso(new Date(now.getTime() + config.orderTtlMinutes * 60000)));
        return db.prepare('SELECT * FROM payment_orders WHERE id = ?').get(Number(info.lastInsertRowid));
      } catch (e) { if (!isUniqueError(e)) throw e; }
    }
    throw new HttpError(500, 'Захиалга үүсгэж чадсангүй.');
  });
}

const getOrderForUser = (db, ref, userId) =>
  db.prepare('SELECT * FROM payment_orders WHERE ref = ? AND user_id = ?').get(ref, userId) || null;

/** User says "I paid". This NEVER marks the order PAID: it only queues it for independent review. */
function submitForReview(db, { ref, userId, userReference, receipt, now }) {
  return tx(db, () => {
    expireStale(db, now);
    const o = getOrderForUser(db, ref, userId);
    if (!o) throw new HttpError(404, 'Захиалга олдсонгүй.');
    if (o.status !== 'CREATED') throw new HttpError(409, 'Энэ захиалгыг шалгалтад илгээх боломжгүй төлөвтэй байна.');
    const r = db.prepare(
      `UPDATE payment_orders SET status = 'PENDING_REVIEW', submitted_at = ?, user_reference = ?, receipt_file = ?, receipt_mime = ?
       WHERE id = ? AND status = 'CREATED'`)
      .run(iso(now), userReference, receipt ? receipt.file : null, receipt ? receipt.mime : null, o.id);
    if (r.changes !== 1) throw new HttpError(409, 'Захиалгын төлөв өөрчлөгдсөн байна.');
    return db.prepare('SELECT * FROM payment_orders WHERE id = ?').get(o.id);
  });
}

/**
 * The ONLY code path that turns an order into PAID and activates VIP.
 * Callers must have independently verified the money: an administrator checking official bank
 * records (method 'manual_admin') or an authenticated provider confirmation.
 * Idempotent: repeated calls for the same order never create a second subscription.
 */
function settleVerifiedPayment(db, { orderId, provider, providerTxnId, amountMnt, currency = 'MNT', method, verifiedBy = null, reason = null, now }) {
  return tx(db, () => {
    const o = db.prepare('SELECT * FROM payment_orders WHERE id = ?').get(orderId);
    if (!o) throw new HttpError(404, 'Захиалга олдсонгүй.');
    if (o.status === 'PAID') return { alreadyProcessed: true, order: o };
    if (method === 'manual_admin' && o.status !== 'PENDING_REVIEW') throw new HttpError(409, 'Зөвхөн шалгалтад байгаа захиалгыг батлах боломжтой.');
    if (!['PENDING_REVIEW', 'CREATED', 'EXPIRED'].includes(o.status)) throw new HttpError(409, 'Энэ захиалгыг төлөгдсөнд тооцох боломжгүй төлөвтэй байна.');
    if (currency !== o.currency || Number(amountMnt) !== o.amount_mnt) throw new HttpError(422, 'Төлбөрийн дүн эсвэл валют захиалгатай таарахгүй байна.');
    if (!providerTxnId) throw new HttpError(422, 'Гүйлгээний лавлагаа шаардлагатай.');
    try {
      db.prepare(
        `INSERT INTO payment_transactions (order_id, provider, provider_txn_id, amount_mnt, currency, state, verification_method, verified_by, verified_at)
         VALUES (?,?,?,?,?, 'PAID', ?, ?, ?)`)
        .run(o.id, provider, String(providerTxnId), o.amount_mnt, o.currency, method, verifiedBy, iso(now));
    } catch (e) {
      if (isUniqueError(e)) throw new HttpError(409, 'Энэ гүйлгээний лавлагаа өмнө нь ашиглагдсан байна.');
      throw e;
    }
    const upd = db.prepare(
      `UPDATE payment_orders SET status = 'PAID', paid_at = ?, reviewed_by = COALESCE(?, reviewed_by), reviewed_at = ?, review_reason = COALESCE(?, review_reason), bank_txn_ref = ?
       WHERE id = ? AND status IN ('PENDING_REVIEW','CREATED','EXPIRED')`)
      .run(iso(now), verifiedBy, iso(now), reason, String(providerTxnId), o.id);
    if (upd.changes !== 1) return { alreadyProcessed: true, order: db.prepare('SELECT * FROM payment_orders WHERE id = ?').get(o.id) };
    const sub = extendSubscription(db, { userId: o.user_id, planId: o.plan_id, months: o.months, orderId: o.id, source: 'payment', now });
    if (verifiedBy) audit(db, now, verifiedBy, 'payment.approve', 'payment_order', o.ref, reason, { bankTxnRef: providerTxnId, amountMnt, subscriptionEnds: sub.endsAt });
    return { alreadyProcessed: false, order: db.prepare('SELECT * FROM payment_orders WHERE id = ?').get(o.id), subscription: sub };
  });
}

/** Admin approval of a manually reviewed order. Separation of duties: admins cannot approve their own orders. */
function approveManual(db, { ref, adminId, bankTxnRef, amountMnt, reason, now }) {
  const o = db.prepare('SELECT * FROM payment_orders WHERE ref = ?').get(ref);
  if (!o) throw new HttpError(404, 'Захиалга олдсонгүй.');
  if (o.user_id === adminId) throw new HttpError(403, 'Өөрийн захиалгыг өөрөө батлах боломжгүй.');
  if (!reason || reason.trim().length < 5) throw new HttpError(422, 'Шалтгаан (хамгийн багадаа 5 тэмдэгт) шаардлагатай.');
  return settleVerifiedPayment(db, {
    orderId: o.id, provider: o.provider, providerTxnId: String(bankTxnRef || '').trim(), amountMnt, method: 'manual_admin',
    verifiedBy: adminId, reason: reason.trim(), now,
  });
}

function rejectManual(db, { ref, adminId, reason, now }) {
  return tx(db, () => {
    const o = db.prepare('SELECT * FROM payment_orders WHERE ref = ?').get(ref);
    if (!o) throw new HttpError(404, 'Захиалга олдсонгүй.');
    if (!reason || reason.trim().length < 5) throw new HttpError(422, 'Шалтгаан (хамгийн багадаа 5 тэмдэгт) шаардлагатай.');
    const r = db.prepare("UPDATE payment_orders SET status = 'REJECTED', reviewed_by = ?, reviewed_at = ?, review_reason = ? WHERE id = ? AND status = 'PENDING_REVIEW'")
      .run(adminId, iso(now), reason.trim(), o.id);
    if (r.changes !== 1) throw new HttpError(409, 'Зөвхөн шалгалтад байгаа захиалгыг татгалзах боломжтой.');
    audit(db, now, adminId, 'payment.reject', 'payment_order', o.ref, reason.trim(), null);
    return db.prepare('SELECT * FROM payment_orders WHERE id = ?').get(o.id);
  });
}

/**
 * Handles a provider callback. Unauthenticated or malformed callbacks are recorded and ignored.
 * Duplicate (provider, eventId) pairs are acknowledged without reprocessing.
 */
function handleProviderCallback(db, providers, { providerName, rawBody, headers, now }) {
  const p = providers.get(providerName);
  if (!p || typeof p.verifyWebhook !== 'function') return { status: 404 };
  let evt = null;
  try { evt = p.verifyWebhook(rawBody, headers); } catch { evt = null; }
  if (!evt) return { status: 401 }; // unsigned/forged: never grants anything
  const eventId = String(evt.eventId || '');
  if (!eventId) return { status: 400 };
  return tx(db, () => {
    try {
      db.prepare('INSERT INTO webhook_events (provider, event_id, received_at, signature_valid, outcome) VALUES (?,?,?,1,?)').run(p.name, eventId, iso(now), 'received');
    } catch (e) {
      if (isUniqueError(e)) return { status: 200, duplicate: true };
      throw e;
    }
    const o = db.prepare('SELECT * FROM payment_orders WHERE ref = ?').get(String(evt.orderRef || ''));
    if (!o || o.provider !== p.name) { db.prepare('UPDATE webhook_events SET outcome = ? WHERE provider = ? AND event_id = ?').run('unknown_order', p.name, eventId); return { status: 200 }; }
    if (evt.state !== 'PAID') { db.prepare('UPDATE webhook_events SET outcome = ? WHERE provider = ? AND event_id = ?').run(`state_${String(evt.state).slice(0, 20)}`, p.name, eventId); return { status: 200 }; }
    try {
      const r = settleVerifiedPayment(db, { orderId: o.id, provider: p.name, providerTxnId: evt.providerTxnId, amountMnt: evt.amountMnt, currency: evt.currency, method: 'provider_webhook', now });
      db.prepare('UPDATE webhook_events SET outcome = ? WHERE provider = ? AND event_id = ?').run(r.alreadyProcessed ? 'already_paid' : 'paid', p.name, eventId);
    } catch (e) {
      if (!(e instanceof HttpError)) throw e;
      db.prepare('UPDATE webhook_events SET outcome = ? WHERE provider = ? AND event_id = ?').run(`rejected_${e.status}`, p.name, eventId);
    }
    return { status: 200 };
  });
}

module.exports = { createOrder, getOrderForUser, submitForReview, settleVerifiedPayment, approveManual, rejectManual, handleProviderCallback, expireStale, audit };
