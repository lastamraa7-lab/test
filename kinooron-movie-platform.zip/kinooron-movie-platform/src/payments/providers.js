'use strict';
// Payment-provider abstraction.
//
// A provider describes HOW an order is paid and HOW a payment may be verified:
//   name            stable identifier stored on the order
//   automatic       true only if the provider can independently confirm money arrived
//   describe(order) data the checkout page needs (QR image, instructions)
//   verifyWebhook(rawBody, headers) -> { eventId, orderRef, providerTxnId, amountMnt, currency, state } | null
//                   MUST authenticate the sender cryptographically; return null when unauthenticated.
//
// Nothing here talks to a bank. The personal-QR provider is manual by design: a personal QR image
// cannot tell this website that money arrived, so every payment goes through admin review.

function createManualQrProvider(config) {
  return {
    name: 'manual_khan_qr',
    automatic: false,
    describe(order) {
      return {
        qrImage: config.qrImage,
        qrIsPlaceholder: config.qrIsPlaceholder,
        payeeLabel: config.payeeLabel,
        amountMnt: order.amount_mnt,
        reference: order.ref,
      };
    },
    verifyWebhook() { return null; }, // a personal QR has no callback channel
  };
}

/**
 * Placeholder for an official KHAN BANK merchant API or authorized aggregator.
 * Intentionally NOT implemented: endpoints, credentials and signature formats must come from the
 * provider's official documentation. Until then every callback is rejected.
 */
function createUnconfiguredBankProvider() {
  return {
    name: 'khan_bank_official',
    automatic: true,
    configured: false,
    describe() { throw new Error('Official bank provider is not configured'); },
    verifyWebhook() { return null; },
  };
}

/** TEST ONLY: simulates an authenticated provider callback with a shared-secret HMAC. Not a bank. */
function createTestProvider(secret) {
  const crypto = require('node:crypto');
  return {
    name: 'test_simulated',
    automatic: true,
    describe(order) { return { qrImage: '/img/khan-qr-placeholder.svg', qrIsPlaceholder: true, amountMnt: order.amount_mnt, reference: order.ref }; },
    sign(rawBody) { return crypto.createHmac('sha256', secret).update(rawBody).digest('hex'); },
    verifyWebhook(rawBody, headers) {
      const sig = String(headers['x-test-signature'] || '');
      const want = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
      const a = Buffer.from(sig);
      const b = Buffer.from(want);
      if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
      try { return JSON.parse(rawBody.toString('utf8')); } catch { return null; }
    },
  };
}

function createRegistry(config) {
  const manual = createManualQrProvider(config);
  const providers = new Map([[manual.name, manual]]);
  const bank = createUnconfiguredBankProvider();
  providers.set(bank.name, bank);
  return {
    default: manual,
    get: (name) => providers.get(name) || null,
    register(p) { providers.set(p.name, p); },
  };
}

module.exports = { createRegistry, createTestProvider };
