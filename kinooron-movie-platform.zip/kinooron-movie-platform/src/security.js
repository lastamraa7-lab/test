'use strict';
const crypto = require('node:crypto');
const { promisify } = require('node:util');

const scrypt = promisify(crypto.scrypt);
const argon2 = crypto.argon2 ? promisify(crypto.argon2) : null; // Node >= 24.7

const randomToken = (bytes = 32) => crypto.randomBytes(bytes).toString('base64url');
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

function safeEqual(a, b) {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

const SCRYPT = { N: 32768, r: 8, p: 1, keylen: 64, maxmem: 128 * 1024 * 1024 };

/** Argon2id when the runtime provides it (Node 24.7+), otherwise scrypt (OWASP-accepted). */
async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  if (argon2) {
    const h = await argon2('argon2id', { message: password, nonce: salt, parallelism: 1, tagLength: 32, memory: 19456, passes: 2 });
    return `argon2id$19456$2$1$${salt.toString('base64')}$${Buffer.from(h).toString('base64')}`;
  }
  const h = await scrypt(password, salt, SCRYPT.keylen, { N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p, maxmem: SCRYPT.maxmem });
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('base64')}$${h.toString('base64')}`;
}

async function verifyPassword(password, stored) {
  try {
    const [kind, a, b, c, saltB64, hashB64] = String(stored).split('$');
    const salt = Buffer.from(saltB64, 'base64');
    const expected = Buffer.from(hashB64, 'base64');
    let actual;
    if (kind === 'scrypt') {
      actual = await scrypt(password, salt, expected.length, { N: +a, r: +b, p: +c, maxmem: SCRYPT.maxmem });
    } else if (kind === 'argon2id' && argon2) {
      actual = Buffer.from(await argon2('argon2id', { message: password, nonce: salt, memory: +a, passes: +b, parallelism: +c, tagLength: expected.length }));
    } else return false;
    return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

let dummy;
/** Burn comparable time when the account does not exist (limits user enumeration by timing). */
async function dummyVerify(password) {
  dummy = dummy || (await hashPassword('dummy-password-for-timing'));
  await verifyPassword(password, dummy);
}

const COMMON = new Set(['password123', '1234567890', 'qwertyuiop', 'passw0rd123', 'iloveyou123', '0123456789', 'password1234', 'qwerty12345']);
function passwordProblem(pw, username = '') {
  if (typeof pw !== 'string' || pw.length < 10) return 'Нууц үг хамгийн багадаа 10 тэмдэгттэй байх ёстой.';
  if (pw.length > 200) return 'Нууц үг хэт урт байна.';
  if (COMMON.has(pw.toLowerCase())) return 'Энэ нууц үг хэт энгийн байна.';
  if (username && pw.toLowerCase().includes(username.toLowerCase())) return 'Нууц үг нэвтрэх нэрийг агуулж болохгүй.';
  if (!/\p{L}/u.test(pw) || !/[\p{N}\p{P}\p{S}]/u.test(pw)) return 'Нууц үг үсэг болон тоо эсвэл тэмдэгт агуулсан байх ёстой.';
  return null;
}

/** Sliding-window in-memory limiter. Single-process only; use a shared store or proxy limiter when scaling out. */
class RateLimiter {
  constructor(now) { this.hits = new Map(); this.now = now; }
  /** Returns true if the request is allowed. */
  take(key, limit, windowMs) {
    const t = this.now().getTime();
    const arr = (this.hits.get(key) || []).filter((x) => t - x < windowMs);
    if (arr.length >= limit) { this.hits.set(key, arr); return false; }
    arr.push(t);
    this.hits.set(key, arr);
    if (this.hits.size > 50000) this.hits.clear();
    return true;
  }
  reset() { this.hits.clear(); }
}

module.exports = { randomToken, sha256, safeEqual, hashPassword, verifyPassword, dummyVerify, passwordProblem, RateLimiter };
