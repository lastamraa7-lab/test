'use strict';
const { createApp } = require('./app');

const app = createApp();
app.listen().then((port) => {
  console.log(`${app.config.siteName} is listening on http://localhost:${port} (${app.config.env}, catalog: ${app.catalog.name}${app.catalog.isSample ? ' SAMPLE DATA' : ''}, mail: ${app.config.mailMode})`);
  if (app.config.qrIsPlaceholder) console.warn('WARNING: KHAN_QR_IMAGE is not set; checkout shows a PLACEHOLDER QR. Do not accept real payments.');
  if (app.config.isProd && app.config.mailMode === 'none') console.warn('WARNING: no mail transport configured; email verification and password recovery are unavailable.');
});
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => app.close().then(() => process.exit(0)));
