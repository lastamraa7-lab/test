'use strict';
const { iso } = require('./util');

/**
 * Mail delivery. Only two modes exist:
 *  - "outbox": development sink (rows in the outbox table). Refused in production by config.
 *  - "none":   no mail channel. Verification links and password recovery are unavailable.
 * To send real email, implement send() against your provider (SMTP/API) and set MAIL_MODE accordingly.
 */
function createMailer(db, config) {
  return {
    available: config.mailMode !== 'none',
    send({ to, subject, body }) {
      if (config.mailMode === 'outbox') {
        db.prepare('INSERT INTO outbox (to_email, subject, body, created_at) VALUES (?,?,?,?)').run(to, subject, body, iso(config.now()));
        return true;
      }
      return false;
    },
  };
}
module.exports = { createMailer };
