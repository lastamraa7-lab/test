'use strict';
const { html } = require('../views/html');
const { layout, csrfInput, field } = require('../views/layout');
const A = require('../auth');
const S = require('../security');
const { tx, isUniqueError } = require('../db');
const { iso, safeNext } = require('../util');

const USERNAME_RE = /^[\p{L}\p{N}_]{3,24}$/u;
const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/;

module.exports = function register(app) {
  const { router, db, config, mailer } = app;
  const baseUrl = (ctx) => config.baseUrl || (config.isProd ? '' : `http://${ctx.req.headers.host}`);

  const errorList = (errors) => (errors.length ? html`<ul class="form-errors" role="alert">${errors.map((e) => html`<li>${e}</li>`)}</ul>` : '');

  function registerPage(ctx, errors = [], v = {}, status = 200) {
    ctx.ensureSession();
    ctx.html(layout(ctx, { title: 'Бүртгүүлэх', body: html`<section class="narrow"><h1>Бүртгүүлэх</h1>
      ${errorList(errors)}
      <form method="post" action="/register" class="form" novalidate>${csrfInput(ctx)}
        ${field({ id: 'username', label: 'Нэвтрэх нэр', value: v.username || '', autocomplete: 'username', help: '3–24 тэмдэгт: үсэг, тоо, доогуур зураас.', attrs: { minlength: 3, maxlength: 24 } })}
        ${field({ id: 'email', label: 'Имэйл', type: 'email', value: v.email || '', autocomplete: 'email', attrs: { maxlength: 254 } })}
        ${field({ id: 'password', label: 'Нууц үг', type: 'password', autocomplete: 'new-password', help: 'Хамгийн багадаа 10 тэмдэгт.', attrs: { minlength: 10, maxlength: 200 } })}
        ${field({ id: 'password2', label: 'Нууц үг давтах', type: 'password', autocomplete: 'new-password', attrs: { maxlength: 200 } })}
        <div class="field check"><input id="terms" name="terms" type="checkbox" required><label for="terms"><a href="/terms" target="_blank" rel="noopener">Үйлчилгээний нөхцөл</a> болон <a href="/privacy" target="_blank" rel="noopener">Нууцлалын бодлого</a>-той танилцаж, зөвшөөрч байна.</label></div>
        <button class="btn btn-primary" type="submit">Бүртгүүлэх</button>
      </form><p class="muted">Бүртгэлтэй юу? <a href="/login">Нэвтрэх</a></p></section>` }), status);
  }

  router.get('/register', (ctx) => (ctx.user ? ctx.redirect('/account') : registerPage(ctx)));

  router.post('/register', async (ctx) => {
    ctx.limit(`register:${ctx.ip}`, 10, 3600000);
    const b = ctx.body;
    const username = String(b.username || '').trim();
    const email = String(b.email || '').trim();
    const errors = [];
    if (!USERNAME_RE.test(username)) errors.push('Нэвтрэх нэр 3–24 тэмдэгттэй, зөвхөн үсэг, тоо, доогуур зураас агуулсан байх ёстой.');
    if (!EMAIL_RE.test(email) || email.length > 254) errors.push('Имэйл хаяг буруу байна.');
    const pwProblem = S.passwordProblem(b.password, username);
    if (pwProblem) errors.push(pwProblem);
    else if (b.password !== b.password2) errors.push('Нууц үг давтан оруулсантай таарахгүй байна.');
    if (b.terms !== 'on') errors.push('Үйлчилгээний нөхцөл, нууцлалын бодлогыг зөвшөөрөх шаардлагатай.');
    if (!errors.length) {
      if (db.prepare('SELECT 1 FROM users WHERE username_lc = ?').get(username.toLowerCase())) errors.push('Энэ нэвтрэх нэр аль хэдийн бүртгэлтэй байна.');
      if (db.prepare('SELECT 1 FROM users WHERE email_lc = ?').get(email.toLowerCase())) errors.push('Энэ имэйл хаяг аль хэдийн бүртгэлтэй байна.');
    }
    if (errors.length) return registerPage(ctx, errors, { username, email }, 400);

    const hash = await S.hashPassword(b.password);
    const now = ctx.now();
    let userId;
    try {
      userId = tx(db, () => Number(db.prepare(
        `INSERT INTO users (public_id, username, username_lc, email, email_lc, password_hash, terms_accepted_at, created_at, updated_at)
         VALUES (?,?,?,?,?,?,?,?,?)`)
        .run(`usr_${S.randomToken(6)}`, username, username.toLowerCase(), email, email.toLowerCase(), hash, iso(now), iso(now), iso(now)).lastInsertRowid));
    } catch (e) {
      if (isUniqueError(e)) return registerPage(ctx, ['Энэ нэвтрэх нэр эсвэл имэйл бүртгэлтэй байна.'], { username, email }, 400);
      throw e;
    }
    ctx.log('user_registered', { userId });
    let note = 'Бүртгэл амжилттай үүслээ.';
    if (mailer.available && baseUrl(ctx)) {
      const token = A.createEmailToken(db, config, userId, 'verify', 60 * 24);
      mailer.send({ to: email, subject: `${config.siteName}: имэйл баталгаажуулах`, body: `Имэйлээ баталгаажуулахын тулд дараах холбоосоор орно уу:\n${baseUrl(ctx)}/verify-email?token=${token}\n` });
      note += ' Имэйл хаягаа баталгаажуулах холбоос илгээлээ.';
    }
    ctx.login(userId);
    ctx.redirect('/account', ['success', note]);
  });

  function loginPage(ctx, errors = [], v = {}, status = 200) {
    ctx.ensureSession();
    ctx.html(layout(ctx, { title: 'Нэвтрэх', body: html`<section class="narrow"><h1>Нэвтрэх</h1>
      ${errorList(errors)}
      <form method="post" action="/login" class="form">${csrfInput(ctx)}
        <input type="hidden" name="next" value="${v.next || ''}">
        ${field({ id: 'identifier', label: 'Нэвтрэх нэр эсвэл имэйл', value: v.identifier || '', autocomplete: 'username', attrs: { maxlength: 254 } })}
        ${field({ id: 'password', label: 'Нууц үг', type: 'password', autocomplete: 'current-password', attrs: { maxlength: 200 } })}
        <button class="btn btn-primary" type="submit">Нэвтрэх</button>
      </form>
      <p class="muted"><a href="/forgot">Нууц үгээ мартсан уу?</a> · <a href="/register">Бүртгүүлэх</a></p></section>` }), status);
  }

  router.get('/login', (ctx) => (ctx.user ? ctx.redirect('/account') : loginPage(ctx, [], { next: safeNext(ctx.query.next) })));

  router.post('/login', async (ctx) => {
    const identifier = String(ctx.body.identifier || '').trim().slice(0, 254);
    const password = String(ctx.body.password || '');
    const next = safeNext(ctx.body.next);
    ctx.limit(`login-ip:${ctx.ip}`, 30, 15 * 60000);
    ctx.limit(`login-id:${identifier.toLowerCase()}`, 8, 15 * 60000);
    const fail = (msg = 'Нэвтрэх нэр эсвэл нууц үг буруу байна.') => { ctx.log('login_failed', { ip: ctx.ip }); return loginPage(ctx, [msg], { identifier, next }, 401); };
    if (!identifier || !password || password.length > 200) return fail();
    const u = db.prepare('SELECT * FROM users WHERE username_lc = ? OR email_lc = ?').get(identifier.toLowerCase(), identifier.toLowerCase());
    if (!u) { await S.dummyVerify(password); return fail(); }
    if (!(await S.verifyPassword(password, u.password_hash))) return fail();
    if (u.status !== 'active') return fail('Таны бүртгэл идэвхгүй болсон байна. Тусламж авахын тулд холбоо барина уу.');
    ctx.login(u.id);
    ctx.log('login_ok', { userId: u.id });
    ctx.redirect(next, ['success', 'Тавтай морил!']);
  });

  router.post('/logout', (ctx) => {
    ctx.logout();
    ctx.ensureSession();
    ctx.flashNext('info', 'Системээс гарлаа.');
    ctx.redirect('/');
  });

  router.get('/verify-email', (ctx) => {
    const t = A.peekEmailToken(db, config, ctx.query.token, 'verify');
    if (!t) return ctx.redirect(ctx.user ? '/account' : '/login', ['error', 'Баталгаажуулах холбоос буруу эсвэл хугацаа дууссан байна.']);
    tx(db, () => {
      if (A.consumeEmailToken(db, config, t.id)) db.prepare('UPDATE users SET email_verified_at = ?, updated_at = ? WHERE id = ? AND email_verified_at IS NULL').run(iso(ctx.now()), iso(ctx.now()), t.user_id);
    });
    return ctx.redirect(ctx.user ? '/account' : '/login', ['success', 'Имэйл хаяг баталгаажлаа.']);
  });

  router.get('/forgot', (ctx) => {
    ctx.ensureSession();
    ctx.html(layout(ctx, { title: 'Нууц үг сэргээх', body: html`<section class="narrow"><h1>Нууц үг сэргээх</h1>
      ${mailer.available ? html`<form method="post" action="/forgot" class="form">${csrfInput(ctx)}
        ${field({ id: 'email', label: 'Бүртгэлтэй имэйл', type: 'email', autocomplete: 'email', attrs: { maxlength: 254 } })}
        <button class="btn btn-primary" type="submit">Сэргээх холбоос илгээх</button></form>`
        : html`<p class="notice-inline">Энэ сайтад имэйл илгээх суваг одоогоор тохируулагдаагүй тул нууц үгийг өөрөө сэргээх боломжгүй байна. <a href="/contact">Администратортай холбогдоно уу.</a></p>`}
      </section>` }));
  });

  router.post('/forgot', (ctx) => {
    ctx.limit(`forgot:${ctx.ip}`, 5, 3600000);
    const email = String(ctx.body.email || '').trim().toLowerCase().slice(0, 254);
    ctx.limit(`forgot-id:${email}`, 3, 3600000);
    if (mailer.available && baseUrl(ctx)) {
      const u = db.prepare("SELECT id, email FROM users WHERE email_lc = ? AND status = 'active'").get(email);
      if (u) {
        const token = A.createEmailToken(db, config, u.id, 'reset', 60);
        mailer.send({ to: u.email, subject: `${config.siteName}: нууц үг сэргээх`, body: `Нууц үгээ шинэчлэх холбоос (1 цагийн дотор хүчинтэй):\n${baseUrl(ctx)}/reset?token=${token}\nХэрэв та хүсэлт гаргаагүй бол энэ захидлыг үл тоомсорлоно уу.\n` });
      }
    }
    // Same response whether or not the address exists.
    ctx.redirect('/login', ['info', 'Хэрэв энэ имэйл бүртгэлтэй бол сэргээх холбоос илгээгдсэн болно.']);
  });

  router.get('/reset', (ctx) => {
    const t = A.peekEmailToken(db, config, ctx.query.token, 'reset');
    if (!t) return ctx.redirect('/forgot', ['error', 'Сэргээх холбоос буруу эсвэл хугацаа дууссан байна.']);
    ctx.ensureSession();
    return ctx.html(layout(ctx, { title: 'Шинэ нууц үг', body: html`<section class="narrow"><h1>Шинэ нууц үг тохируулах</h1>
      <form method="post" action="/reset" class="form">${csrfInput(ctx)}<input type="hidden" name="token" value="${ctx.query.token}">
        ${field({ id: 'password', label: 'Шинэ нууц үг', type: 'password', autocomplete: 'new-password', attrs: { minlength: 10, maxlength: 200 } })}
        ${field({ id: 'password2', label: 'Нууц үг давтах', type: 'password', autocomplete: 'new-password', attrs: { maxlength: 200 } })}
        <button class="btn btn-primary" type="submit">Хадгалах</button></form></section>` }));
  });

  router.post('/reset', async (ctx) => {
    ctx.limit(`reset:${ctx.ip}`, 10, 3600000);
    const token = String(ctx.body.token || '');
    const t = A.peekEmailToken(db, config, token, 'reset');
    if (!t) return ctx.redirect('/forgot', ['error', 'Сэргээх холбоос буруу эсвэл хугацаа дууссан байна.']);
    const u = db.prepare('SELECT username FROM users WHERE id = ?').get(t.user_id);
    const problem = S.passwordProblem(ctx.body.password, u.username) || (ctx.body.password !== ctx.body.password2 ? 'Нууц үг давтан оруулсантай таарахгүй байна.' : null);
    if (problem) return ctx.redirect(`/reset?token=${encodeURIComponent(token)}`, ['error', problem]);
    const hash = await S.hashPassword(ctx.body.password);
    tx(db, () => {
      if (!A.consumeEmailToken(db, config, t.id)) return;
      db.prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?').run(hash, iso(ctx.now()), t.user_id);
      A.destroyUserSessions(db, t.user_id);
    });
    ctx.log('password_reset', { userId: t.user_id });
    return ctx.redirect('/login', ['success', 'Нууц үг шинэчлэгдлээ. Шинэ нууц үгээрээ нэвтэрнэ үү.']);
  });
};
