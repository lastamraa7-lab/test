'use strict';
const { html } = require('../views/html');
const { layout, csrfInput, field, posterCard, statusLabel, fmtMnt, fmtDate, fmtDateTime } = require('../views/layout');
const S = require('../security');
const A = require('../auth');
const { iso } = require('../util');
const { listSubscriptions } = require('../subscriptions');
const { expireStale } = require('../payments/service');

module.exports = function register(app) {
  const { router, db, catalog, config } = app;

  async function titles(ids) {
    const out = [];
    for (const id of ids.slice(0, 24)) { const t = await catalog.get(id).catch(() => null); if (t) out.push(t); }
    return out;
  }

  router.get('/account', async (ctx) => {
    const u = ctx.user;
    expireStale(db, ctx.now());
    const orders = db.prepare('SELECT * FROM payment_orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 20').all(u.id);
    const subs = listSubscriptions(db, u.id);
    const lists = db.prepare('SELECT title_id, kind FROM user_watchlists WHERE user_id = ? ORDER BY created_at DESC').all(u.id);
    const history = db.prepare('SELECT * FROM viewing_history WHERE user_id = ? ORDER BY updated_at DESC LIMIT 24').all(u.id);
    const [watch, fav, hist] = await Promise.all([
      titles(lists.filter((l) => l.kind === 'watchlist').map((l) => l.title_id)),
      titles(lists.filter((l) => l.kind === 'favorite').map((l) => l.title_id)),
      titles(history.map((h) => h.title_id)),
    ]);
    const grid = (items, empty) => (items.length ? html`<div class="grid grid-sm">${items.map((m) => posterCard(m))}</div>` : html`<p class="muted">${empty}</p>`);
    const body = html`<h1>Миний бүртгэл</h1>
      <section class="panel"><h2>Профайл</h2>
        <dl class="facts">
          <dt>Нэвтрэх нэр</dt><dd>${u.username}</dd>
          <dt>Хэрэглэгчийн ID</dt><dd><code>${u.public_id}</code></dd>
          <dt>Имэйл</dt><dd>${u.email} — ${u.email_verified_at ? html`<span class="badge badge-ok">Баталгаажсан</span>` : html`<span class="badge">Баталгаажаагүй</span>`}</dd>
          <dt>VIP төлөв</dt><dd>${ctx.vip.active ? html`<span class="badge badge-vip">VIP идэвхтэй</span> ${fmtDate(ctx.vip.startsAt)} → ${fmtDate(ctx.vip.endsAt)} хүртэл` : html`VIP эрхгүй${ctx.vip.lastEndedAt ? ` (сүүлийн эрх ${fmtDate(ctx.vip.lastEndedAt)}-д дууссан)` : ''} · <a href="/vip">VIP авах</a>`}</dd>
          <dt>Бүртгүүлсэн</dt><dd>${fmtDate(u.created_at)}</dd>
        </dl></section>
      <section class="panel"><h2>Төлбөрийн түүх</h2>
        ${orders.length ? html`<div class="table-wrap"><table><thead><tr><th>Лавлагаа</th><th>Багц</th><th>Дүн</th><th>Төлөв</th><th>Огноо</th></tr></thead><tbody>
          ${orders.map((o) => html`<tr><td><a href="/orders/${o.ref}">${o.ref}</a></td><td>${o.plan_name}</td><td>${fmtMnt(o.amount_mnt)}</td><td>${statusLabel(o.status)}</td><td>${fmtDateTime(o.created_at)}</td></tr>`)}</tbody></table></div>` : html`<p class="muted">Төлбөрийн түүх байхгүй.</p>`}
        ${subs.length ? html`<h3>Эрхийн түүх</h3><ul>${subs.map((s) => html`<li>${s.plan_name || 'Гараар олгосон'} · ${fmtDate(s.starts_at)} → ${fmtDate(s.ends_at)}${s.revoked_at ? ' · цуцлагдсан' : ''}</li>`)}</ul>` : ''}
      </section>
      <section class="panel"><h2>Миний жагсаалт</h2>${grid(watch, 'Жагсаалт хоосон байна.')}</section>
      <section class="panel"><h2>Дуртай</h2>${grid(fav, 'Дуртай контент сонгоогүй байна.')}</section>
      <section class="panel"><h2>Үзсэн түүх</h2>${grid(hist, 'Үзсэн түүх байхгүй.')}</section>
      <section class="panel"><h2>Тохиргоо — нууц үг солих</h2>
        <form method="post" action="/account/password" class="form">${csrfInput(ctx)}
          ${field({ id: 'current', label: 'Одоогийн нууц үг', type: 'password', autocomplete: 'current-password', attrs: { maxlength: 200 } })}
          ${field({ id: 'password', label: 'Шинэ нууц үг', type: 'password', autocomplete: 'new-password', attrs: { minlength: 10, maxlength: 200 } })}
          ${field({ id: 'password2', label: 'Шинэ нууц үг давтах', type: 'password', autocomplete: 'new-password', attrs: { maxlength: 200 } })}
          <button class="btn btn-primary" type="submit">Нууц үг солих</button></form></section>
      <form method="post" action="/logout">${csrfInput(ctx)}<button class="btn btn-ghost" type="submit">Гарах</button></form>`;
    ctx.html(layout(ctx, { title: 'Миний бүртгэл', body }));
  }, { auth: 'user' });

  router.post('/account/password', async (ctx) => {
    ctx.limit(`pwchange:${ctx.user.id}`, 6, 3600000);
    const row = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(ctx.user.id);
    if (!(await S.verifyPassword(String(ctx.body.current || ''), row.password_hash))) return ctx.redirect('/account', ['error', 'Одоогийн нууц үг буруу байна.']);
    const problem = S.passwordProblem(ctx.body.password, ctx.user.username) || (ctx.body.password !== ctx.body.password2 ? 'Шинэ нууц үг давтан оруулсантай таарахгүй байна.' : null);
    if (problem) return ctx.redirect('/account', ['error', problem]);
    const hash = await S.hashPassword(ctx.body.password);
    db.prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?').run(hash, iso(ctx.now()), ctx.user.id);
    A.destroyUserSessions(db, ctx.user.id, ctx.session.hash); // sign out other devices
    ctx.log('password_changed', { userId: ctx.user.id });
    return ctx.redirect('/account', ['success', 'Нууц үг амжилттай солигдлоо. Бусад төхөөрөмжөөс гарлаа.']);
  }, { auth: 'user' });
};
