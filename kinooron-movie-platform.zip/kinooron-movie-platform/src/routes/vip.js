'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { html } = require('../views/html');
const { layout, csrfInput, statusLabel, fmtMnt, fmtDate, fmtDateTime } = require('../views/layout');
const { HttpError, intParam } = require('../util');
const P = require('../payments/service');
const { randomToken } = require('../security');

// Receipt images: allow-list by magic bytes, never trust the client-supplied name or type.
const SIGNATURES = [
  { mime: 'image/png', ext: 'png', test: (b) => b.length > 8 && b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) },
  { mime: 'image/jpeg', ext: 'jpg', test: (b) => b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  { mime: 'image/webp', ext: 'webp', test: (b) => b.length > 12 && b.subarray(0, 4).toString() === 'RIFF' && b.subarray(8, 12).toString() === 'WEBP' },
];
const MAX_RECEIPT = 2 * 1024 * 1024;

module.exports = function register(app) {
  const { router, db, config, providers } = app;

  router.get('/vip', (ctx) => {
    const plans = db.prepare('SELECT * FROM subscription_plans WHERE active = 1 ORDER BY sort_order').all();
    const body = html`<section><h1>VIP эрх</h1>
      <p class="lead">VIP эрхтэй бол зөвхөн VIP гэж тэмдэглэсэн контентыг үзэх боломжтой. Төлбөр автоматаар сунгагдахгүй — та сунгах бүртээ өөрөө шийднэ.</p>
      ${ctx.vip && ctx.vip.active ? html`<p class="notice-inline">Таны VIP ${fmtDate(ctx.vip.endsAt)} хүртэл идэвхтэй. Шинэ багц авбал одоогийн дуусах огнооноос үргэлжилнэ.</p>` : ''}
      ${plans.length ? html`<div class="plans">${plans.map((p) => html`<form class="plan" method="post" action="/vip/checkout">${csrfInput(ctx)}
          <h2>${p.name}</h2><p class="price">${fmtMnt(p.price_mnt)}</p><p class="muted">${p.months} сар · ${fmtMnt(Math.round(p.price_mnt / p.months))}/сар</p>
          <input type="hidden" name="plan" value="${p.id}"><button class="btn btn-primary" type="submit">Сонгох</button></form>`)}</div>`
        : html`<div class="empty"><h2>VIP багц одоогоор нээгдээгүй байна</h2><p>Администратор багцын үнийг тохируулж идэвхжүүлсний дараа энд харагдана.</p></div>`}
      <p class="muted">Төлбөрийн дараа гүйлгээг хүн шалгаж баталгаажуулсны дараа л VIP идэвхжинэ (<a href="/help">Тусламж</a>).</p></section>`;
    ctx.html(layout(ctx, { title: 'VIP эрх', body }));
  });

  router.post('/vip/checkout', (ctx) => {
    if (config.requireVerifiedEmailForPurchase && !ctx.user.email_verified_at) return ctx.redirect('/account', ['error', 'Худалдан авалт хийхийн өмнө имэйл хаягаа баталгаажуулна уу.']);
    ctx.limit(`checkout:${ctx.user.id}`, 20, 3600000);
    const order = P.createOrder(db, config, providers, { userId: ctx.user.id, planId: intParam(ctx.body.plan, 0, 0, 1e9), now: ctx.now() });
    return ctx.redirect(`/orders/${order.ref}`);
  }, { auth: 'user' });

  router.get('/orders/:ref', (ctx) => {
    P.expireStale(db, ctx.now());
    const o = P.getOrderForUser(db, ctx.params.ref, ctx.user.id); // owner-scoped: other users get 404
    if (!o) throw new HttpError(404, 'Захиалга олдсонгүй.');
    const prov = providers.get(o.provider);
    const info = prov && prov.describe ? prov.describe(o) : null;
    const open = o.status === 'CREATED';
    const body = html`<section class="narrow"><h1>Захиалга ${o.ref}</h1>
      <p><span class="badge ${o.status === 'PAID' ? 'badge-ok' : ''}">${statusLabel(o.status)}</span></p>
      <dl class="facts"><dt>Багц</dt><dd>${o.plan_name}</dd><dt>Төлөх дүн</dt><dd><strong>${fmtMnt(o.amount_mnt)}</strong></dd><dt>Гүйлгээний утга</dt><dd><code>${o.ref}</code></dd>
        <dt>Захиалгын хугацаа</dt><dd>${fmtDateTime(o.expires_at)} хүртэл</dd></dl>
      ${open && info ? html`
        ${info.qrIsPlaceholder ? html`<p class="notice-inline" role="alert"><strong>АНХААРУУЛГА:</strong> Энэ нь түр QR зураг. Сайтын эзэн өөрийн Хаан банкны QR зургаа тохируулаагүй байна. Энэ QR-аар бүү шилжүүлээрэй.</p>` : ''}
        <figure class="qr"><img src="${info.qrImage}" alt="Төлбөрийн QR код" width="260" height="260">${info.payeeLabel ? html`<figcaption>Хүлээн авагч: ${info.payeeLabel}</figcaption>` : ''}</figure>
        <ol class="steps">
          <li>Банкны аппаараа QR-ыг уншуулж <strong>яг ${fmtMnt(o.amount_mnt)}</strong> шилжүүлнэ.</li>
          <li>Гүйлгээний утга хэсэгт <code>${o.ref}</code> гэж бичнэ.</li>
          <li>Шилжүүлсний дараа доорх хэсэгт гүйлгээний лавлагаагаа оруулж шалгалтад илгээнэ.</li></ol>
        <p class="notice-inline">Төлбөр автоматаар баталгаажихгүй. Администратор банкны албан ёсны бичилтээс гүйлгээг шалгаж баталгаажуулсны дараа л VIP идэвхжинэ. Скриншот эсвэл баримт нь төлбөр хийгдсэнийг нотлохгүй.
          Банкны нууц үг, ПИН, нэг удаагийн кодыг хэзээ ч бидэнд бүү илгээ.</p>
        <form method="post" action="/orders/${o.ref}/submit" enctype="multipart/form-data" class="form">${csrfInput(ctx)}
          <div class="field"><label for="user_reference">Гүйлгээний лавлагаа / дугаар</label><input id="user_reference" name="user_reference" required maxlength="64" autocomplete="off"></div>
          <div class="field"><label for="receipt">Баримтын зураг (заавал биш, PNG/JPG/WEBP, 2MB хүртэл)</label><input id="receipt" name="receipt" type="file" accept="image/png,image/jpeg,image/webp"></div>
          <button class="btn btn-primary" type="submit">Төлсөн — шалгалтад илгээх</button></form>` : ''}
      ${o.status === 'PENDING_REVIEW' ? html`<p class="notice-inline">Таны хүсэлт шалгалтад байна (${fmtDateTime(o.submitted_at)}). Баталгаажсаны дараа VIP автоматаар идэвхжинэ. Лавлагаа: <code>${o.user_reference}</code></p>` : ''}
      ${o.status === 'REJECTED' ? html`<p class="notice-inline">Хүсэлт татгалзагдсан: ${o.review_reason}. Асуулт байвал <a href="/contact">холбоо барина уу</a>.</p>` : ''}
      ${o.status === 'EXPIRED' ? html`<p class="notice-inline">Захиалгын хугацаа дууссан. <a href="/vip">Шинэ захиалга үүсгэх</a>. Хэрэв та аль хэдийн төлсөн бол <a href="/contact">холбоо барина уу</a>.</p>` : ''}
      ${o.status === 'PAID' ? html`<p class="notice-inline">Төлбөр баталгаажсан. VIP идэвхжсэн. <a href="/account">Бүртгэл рүү очих</a></p>` : ''}
      ${o.receipt_file ? html`<p><a href="/orders/${o.ref}/receipt" target="_blank" rel="noopener">Илгээсэн баримтыг харах</a></p>` : ''}</section>`;
    ctx.html(layout(ctx, { title: `Захиалга ${o.ref}`, body }));
  }, { auth: 'user' });

  router.post('/orders/:ref/submit', (ctx) => {
    ctx.limit(`submit:${ctx.user.id}`, 20, 3600000);
    const ref = String(ctx.body.user_reference || '').trim();
    if (ref.length < 3 || ref.length > 64 || /[\u0000-\u001f<>]/.test(ref)) throw new HttpError(422, 'Гүйлгээний лавлагааг зөв оруулна уу (3–64 тэмдэгт).');
    let receipt = null;
    const f = ctx.files.find((x) => x.field === 'receipt' && x.filename);
    if (f && f.data.length) {
      if (f.data.length > MAX_RECEIPT) throw new HttpError(413, 'Баримтын зураг 2MB-аас бага байх ёстой.');
      const sig = SIGNATURES.find((s) => s.test(f.data));
      if (!sig) throw new HttpError(422, 'Зөвхөн PNG, JPG эсвэл WEBP зураг оруулна уу.');
      const name = `${randomToken(18)}.${sig.ext}`; // server-chosen name, stored outside the public dir
      receipt = { file: name, mime: sig.mime, data: f.data };
    }
    // Verify the order is submittable BEFORE writing the file, then persist atomically.
    const order = P.submitForReview(db, { ref: ctx.params.ref, userId: ctx.user.id, userReference: ref, receipt, now: ctx.now() });
    if (receipt) fs.writeFileSync(path.join(config.uploadDir, receipt.file), receipt.data, { mode: 0o600 });
    ctx.log('order_submitted', { orderId: order.id });
    ctx.redirect(`/orders/${order.ref}`, ['success', 'Хүсэлт шалгалтад илгээгдлээ. Баталгаажсаны дараа VIP идэвхжинэ.']);
  }, { auth: 'user', maxBody: MAX_RECEIPT + 64 * 1024 });

  // Owner or admin only. Served with a server-side content type, never inline-executable.
  router.get('/orders/:ref/receipt', (ctx) => {
    const o = db.prepare('SELECT * FROM payment_orders WHERE ref = ?').get(ctx.params.ref);
    if (!o || !o.receipt_file || (o.user_id !== ctx.user.id && ctx.user.role !== 'admin')) throw new HttpError(404, 'Олдсонгүй.');
    const full = path.join(config.uploadDir, path.basename(o.receipt_file));
    if (!fs.existsSync(full)) throw new HttpError(404, 'Олдсонгүй.');
    ctx.bytes(fs.readFileSync(full), o.receipt_mime, 200, { 'content-disposition': 'inline', 'content-security-policy': "default-src 'none'; sandbox" });
  }, { auth: 'user' });

  // Provider callbacks. No provider with an authenticated callback is configured by default, so every
  // request is rejected (404/401) and can never grant VIP. See src/payments/providers.js.
  router.post('/webhooks/:provider', (ctx) => {
    const r = P.handleProviderCallback(db, providers, { providerName: ctx.params.provider, rawBody: ctx.rawBody, headers: ctx.req.headers, now: ctx.now() });
    if (r.status !== 200) ctx.log('webhook_rejected', { provider: String(ctx.params.provider).slice(0, 40), status: r.status });
    ctx.json({ ok: r.status === 200 }, r.status);
  }, { csrf: false, raw: true });
};
