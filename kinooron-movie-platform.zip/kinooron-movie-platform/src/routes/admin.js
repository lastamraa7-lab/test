'use strict';
const { html, raw } = require('../views/html');
const { layout, csrfInput, statusLabel, fmtMnt, fmtDate, fmtDateTime } = require('../views/layout');
const { HttpError, iso, intParam } = require('../util');
const P = require('../payments/service');
const { getVipStatus, extendSubscription, revokeAll, listSubscriptions } = require('../subscriptions');
const A = require('../auth');
const { tx } = require('../db');

const STATUSES = ['CREATED', 'PENDING_REVIEW', 'PAID', 'REJECTED', 'EXPIRED', 'FAILED', 'REFUNDED'];
const need = (reason) => {
  const r = String(reason || '').trim();
  if (r.length < 5 || r.length > 500) throw new HttpError(422, 'Шалтгаан заавал бөглөх ёстой (5–500 тэмдэгт).');
  return r;
};

module.exports = function register(app) {
  const { router, db, config, catalog } = app;
  const adm = { auth: 'admin' };

  const nav = (cur) => html`<nav class="subnav" aria-label="Админ цэс">
    ${[['/admin', 'Хураангуй'], ['/admin/orders', 'Төлбөрүүд'], ['/admin/users', 'Хэрэглэгчид'], ['/admin/plans', 'VIP багц'], ['/admin/titles', 'Контентын эрх'], ['/admin/audit', 'Аудит']]
      .map(([h, t]) => html`<a href="${h}" ${cur === h ? raw('aria-current="page"') : ''}>${t}</a>`)}</nav>`;
  const page = (ctx, cur, title, body) => ctx.html(layout(ctx, { title: `Админ · ${title}`, body: html`<h1>${title}</h1>${nav(cur)}${body}` }));
  const back = (ctx, to, type, text) => ctx.redirect(to, [type, text]);

  router.get('/admin', (ctx) => {
    const now = iso(ctx.now());
    P.expireStale(db, ctx.now());
    const c = (sql, ...a) => db.prepare(sql).get(...a).c;
    const stats = [
      ['Хэрэглэгч', c('SELECT COUNT(*) c FROM users')],
      ['Идэвхтэй VIP', c('SELECT COUNT(DISTINCT user_id) c FROM subscriptions WHERE revoked_at IS NULL AND starts_at <= ? AND ends_at > ?', now, now)],
      ['Шалгалт хүлээж буй', c("SELECT COUNT(*) c FROM payment_orders WHERE status = 'PENDING_REVIEW'")],
      ['Баталгаажсан төлбөр', c("SELECT COUNT(*) c FROM payment_orders WHERE status = 'PAID'")],
    ];
    const paidNoTxn = c("SELECT COUNT(*) c FROM payment_orders o WHERE o.status = 'PAID' AND NOT EXISTS (SELECT 1 FROM payment_transactions t WHERE t.order_id = o.id)");
    const subNoPaid = c("SELECT COUNT(*) c FROM subscriptions s WHERE s.source = 'payment' AND NOT EXISTS (SELECT 1 FROM payment_orders o WHERE o.id = s.order_id AND o.status = 'PAID')");
    const byMethod = db.prepare('SELECT verification_method m, COUNT(*) c FROM payment_transactions GROUP BY verification_method').all();
    page(ctx, '/admin', 'Хураангуй', html`<div class="stats">${stats.map(([k, v]) => html`<div class="stat"><span class="muted">${k}</span><strong>${v}</strong></div>`)}</div>
      <section class="panel"><h2>Тулган баталгаажуулалт (reconciliation)</h2>
        <ul><li>Гүйлгээний бичлэггүй PAID захиалга: <strong>${paidNoTxn}</strong> ${paidNoTxn ? '⚠ шалгана уу' : '✓'}</li>
        <li>PAID захиалгагүй төлбөрийн эрх: <strong>${subNoPaid}</strong> ${subNoPaid ? '⚠ шалгана уу' : '✓'}</li>
        <li>Баталгаажуулсан арга: ${byMethod.length ? byMethod.map((r) => `${r.m}: ${r.c}`).join(', ') : 'одоогоор байхгүй'}</li></ul>
        <p class="muted">Банкны автомат баталгаажуулалт тохируулагдаагүй: бүх төлбөрийг админ банкны албан ёсны бичлэгтэй тулгаж гараар батална.</p></section>`);
  }, adm);

  router.get('/admin/orders', (ctx) => {
    P.expireStale(db, ctx.now());
    const st = STATUSES.includes(ctx.query.status) ? ctx.query.status : '';
    const rows = db.prepare(`SELECT o.*, u.username FROM payment_orders o JOIN users u ON u.id = o.user_id ${st ? 'WHERE o.status = ?' : ''} ORDER BY o.created_at DESC LIMIT 200`).all(...(st ? [st] : []));
    page(ctx, '/admin/orders', 'Төлбөрүүд', html`<p class="filters-inline"><a href="/admin/orders">Бүгд</a> ${STATUSES.map((s) => html`<a href="/admin/orders?status=${s}" ${st === s ? raw('aria-current="true"') : ''}>${statusLabel(s)}</a>`)}</p>
      <div class="table-wrap"><table><thead><tr><th>Лавлагаа</th><th>Хэрэглэгч</th><th>Багц</th><th>Дүн</th><th>Төлөв</th><th>Үүссэн</th></tr></thead><tbody>
      ${rows.map((o) => html`<tr><td><a href="/admin/orders/${o.ref}">${o.ref}</a></td><td>${o.username}</td><td>${o.plan_name}</td><td>${fmtMnt(o.amount_mnt)}</td><td>${statusLabel(o.status)}</td><td>${fmtDateTime(o.created_at)}</td></tr>`)}</tbody></table></div>
      ${rows.length ? '' : html`<p class="muted">Захиалга олдсонгүй.</p>`}`);
  }, adm);

  router.get('/admin/orders/:ref', (ctx) => {
    const o = db.prepare('SELECT o.*, u.username, u.public_id FROM payment_orders o JOIN users u ON u.id = o.user_id WHERE o.ref = ?').get(ctx.params.ref);
    if (!o) throw new HttpError(404, 'Захиалга олдсонгүй.');
    const txns = db.prepare('SELECT * FROM payment_transactions WHERE order_id = ?').all(o.id);
    const reviewable = o.status === 'PENDING_REVIEW';
    page(ctx, '/admin/orders', `Захиалга ${o.ref}`, html`<dl class="facts"><dt>Төлөв</dt><dd>${statusLabel(o.status)}</dd><dt>Хэрэглэгч</dt><dd>${o.username} (<code>${o.public_id}</code>)</dd>
      <dt>Багц</dt><dd>${o.plan_name} · ${o.months} сар</dd><dt>Хүлээгдэж буй дүн</dt><dd><strong>${fmtMnt(o.amount_mnt)}</strong></dd>
      <dt>Хэрэглэгчийн оруулсан лавлагаа</dt><dd>${o.user_reference || '—'} <span class="muted">(нотлох баримт биш)</span></dd>
      <dt>Илгээсэн</dt><dd>${fmtDateTime(o.submitted_at)}</dd>
      <dt>Баримт</dt><dd>${o.receipt_file ? html`<a href="/orders/${o.ref}/receipt" target="_blank" rel="noopener">Харах</a> <span class="muted">(скриншот нь төлбөрийн нотолгоо биш)</span>` : '—'}</dd>
      <dt>Шалгасан</dt><dd>${o.reviewed_at ? `${fmtDateTime(o.reviewed_at)} · ${o.review_reason || ''}` : '—'}</dd>
      <dt>Банкны гүйлгээ</dt><dd>${txns.length ? txns.map((t) => `${t.provider_txn_id} · ${fmtMnt(t.amount_mnt)} · ${t.verification_method}`).join('; ') : '—'}</dd></dl>
      ${reviewable ? html`<section class="panel"><h2>Батлах</h2>
        <p class="notice-inline">Эхлээд Хаан банкны <strong>албан ёсны бичилтээс</strong> гүйлгээг өөрөө шалгана уу: дүн ${fmtMnt(o.amount_mnt)}, гүйлгээний утга <code>${o.ref}</code>. Хэрэглэгчийн скриншотод бүү найдаарай.</p>
        <form method="post" action="/admin/orders/${o.ref}/approve" class="form">${csrfInput(ctx)}
          <div class="field"><label for="bank_txn_ref">Банкны гүйлгээний лавлагаа (давтагдахгүй)</label><input id="bank_txn_ref" name="bank_txn_ref" required maxlength="64" autocomplete="off"></div>
          <div class="field"><label for="amount_mnt">Банкинд орсон дүн (₮)</label><input id="amount_mnt" name="amount_mnt" type="number" min="1" required inputmode="numeric"></div>
          <div class="field"><label for="reason">Тэмдэглэл / шалтгаан</label><input id="reason" name="reason" required minlength="5" maxlength="500"></div>
          <div class="field check"><input id="confirm" name="confirm" type="checkbox" required><label for="confirm">Би гүйлгээг банкны албан ёсны бичлэгээс өөрөө шалгаж баталгаажуулсан.</label></div>
          <button class="btn btn-primary" type="submit">Батлах ба VIP идэвхжүүлэх</button></form></section>
        <section class="panel"><h2>Татгалзах</h2>
        <form method="post" action="/admin/orders/${o.ref}/reject" class="form">${csrfInput(ctx)}
          <div class="field"><label for="rreason">Шалтгаан</label><input id="rreason" name="reason" required minlength="5" maxlength="500"></div>
          <button class="btn btn-ghost" type="submit">Татгалзах</button></form></section>` : html`<p class="muted">Энэ захиалгыг одоо батлах/татгалзах боломжгүй төлөвтэй байна.</p>`}`);
  }, adm);

  router.post('/admin/orders/:ref/approve', (ctx) => {
    if (ctx.body.confirm !== 'on') throw new HttpError(422, 'Банкны бичлэгээр шалгасан гэдгээ баталгаажуулна уу.');
    ctx.limit(`admin-approve:${ctx.user.id}`, 60, 3600000);
    const r = P.approveManual(db, { ref: ctx.params.ref, adminId: ctx.user.id, bankTxnRef: ctx.body.bank_txn_ref, amountMnt: Number(ctx.body.amount_mnt), reason: ctx.body.reason, now: ctx.now() });
    ctx.log('payment_approved', { orderId: r.order.id, adminId: ctx.user.id });
    back(ctx, `/admin/orders/${ctx.params.ref}`, r.alreadyProcessed ? 'info' : 'success', r.alreadyProcessed ? 'Энэ захиалга өмнө нь батлагдсан байна (давхар идэвхжүүлээгүй).' : `Баталгаажлаа. VIP ${fmtDate(r.subscription.endsAt)} хүртэл.`);
  }, adm);

  router.post('/admin/orders/:ref/reject', (ctx) => {
    P.rejectManual(db, { ref: ctx.params.ref, adminId: ctx.user.id, reason: ctx.body.reason, now: ctx.now() });
    back(ctx, `/admin/orders/${ctx.params.ref}`, 'success', 'Захиалгыг татгалзлаа.');
  }, adm);

  router.get('/admin/users', (ctx) => {
    const q = String(ctx.query.q || '').trim().toLowerCase().slice(0, 60);
    const rows = db.prepare(`SELECT id, public_id, username, email, role, status, email_verified_at, created_at FROM users ${q ? 'WHERE username_lc LIKE ? OR email_lc LIKE ?' : ''} ORDER BY id DESC LIMIT 100`).all(...(q ? [`%${q}%`, `%${q}%`] : []));
    page(ctx, '/admin/users', 'Хэрэглэгчид', html`<form method="get" class="filters-inline"><input name="q" value="${q}" placeholder="Нэр эсвэл имэйл" aria-label="Хайх"><button class="btn btn-ghost">Хайх</button></form>
      <div class="table-wrap"><table><thead><tr><th>Нэр</th><th>Имэйл</th><th>Эрх</th><th>Төлөв</th><th>VIP</th></tr></thead><tbody>
      ${rows.map((u) => { const v = getVipStatus(db, u.id, ctx.now()); return html`<tr><td><a href="/admin/users/${u.id}">${u.username}</a></td><td>${u.email}</td><td>${u.role}</td><td>${u.status}</td><td>${v.active ? `${fmtDate(v.endsAt)} хүртэл` : '—'}</td></tr>`; })}</tbody></table></div>`);
  }, adm);

  router.get('/admin/users/:id', (ctx) => {
    const u = db.prepare('SELECT * FROM users WHERE id = ?').get(intParam(ctx.params.id, 0, 0, 1e12));
    if (!u) throw new HttpError(404, 'Хэрэглэгч олдсонгүй.');
    const v = getVipStatus(db, u.id, ctx.now());
    const plans = db.prepare('SELECT * FROM subscription_plans ORDER BY sort_order').all();
    const subs = listSubscriptions(db, u.id);
    const orders = db.prepare('SELECT * FROM payment_orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 20').all(u.id);
    page(ctx, '/admin/users', `Хэрэглэгч: ${u.username}`, html`<dl class="facts"><dt>ID</dt><dd><code>${u.public_id}</code></dd><dt>Имэйл</dt><dd>${u.email} ${u.email_verified_at ? '(баталгаажсан)' : '(баталгаажаагүй)'}</dd><dt>Эрх</dt><dd>${u.role}</dd><dt>Төлөв</dt><dd>${u.status}</dd>
      <dt>VIP</dt><dd>${v.active ? `${fmtDate(v.startsAt)} → ${fmtDate(v.endsAt)}` : 'Байхгүй'}</dd></dl>
      <section class="panel"><h2>VIP гараар олгох</h2><form method="post" action="/admin/users/${u.id}/vip" class="form">${csrfInput(ctx)}<input type="hidden" name="action" value="grant">
        <div class="field"><label for="plan">Хугацаа</label><select id="plan" name="plan">${plans.map((p) => html`<option value="${p.id}">${p.months} сар</option>`)}</select></div>
        <div class="field"><label for="g_reason">Шалтгаан (заавал)</label><input id="g_reason" name="reason" required minlength="5" maxlength="500"></div>
        <button class="btn btn-primary" type="submit">Олгох</button></form></section>
      <section class="panel"><h2>VIP цуцлах</h2><form method="post" action="/admin/users/${u.id}/vip" class="form">${csrfInput(ctx)}<input type="hidden" name="action" value="revoke">
        <div class="field"><label for="r_reason">Шалтгаан (заавал)</label><input id="r_reason" name="reason" required minlength="5" maxlength="500"></div>
        <button class="btn btn-ghost" type="submit">Цуцлах</button></form></section>
      ${u.id === ctx.user.id ? '' : html`<section class="panel"><h2>Бүртгэлийн төлөв</h2><form method="post" action="/admin/users/${u.id}/status" class="form">${csrfInput(ctx)}<input type="hidden" name="status" value="${u.status === 'active' ? 'disabled' : 'active'}">
        <div class="field"><label for="s_reason">Шалтгаан (заавал)</label><input id="s_reason" name="reason" required minlength="5" maxlength="500"></div>
        <button class="btn btn-ghost" type="submit">${u.status === 'active' ? 'Идэвхгүй болгох' : 'Идэвхжүүлэх'}</button></form></section>`}
      <h2>Эрхийн түүх</h2><ul>${subs.map((s) => html`<li>${s.source} · ${fmtDate(s.starts_at)} → ${fmtDate(s.ends_at)}${s.revoked_at ? ` · цуцлагдсан (${s.revoked_reason})` : ''}</li>`)}</ul>
      <h2>Захиалгууд</h2><ul>${orders.map((o) => html`<li><a href="/admin/orders/${o.ref}">${o.ref}</a> · ${fmtMnt(o.amount_mnt)} · ${statusLabel(o.status)}</li>`)}</ul>`);
  }, adm);

  router.post('/admin/users/:id/vip', (ctx) => {
    const id = intParam(ctx.params.id, 0, 0, 1e12);
    const u = db.prepare('SELECT id FROM users WHERE id = ?').get(id);
    if (!u) throw new HttpError(404, 'Хэрэглэгч олдсонгүй.');
    const reason = need(ctx.body.reason);
    tx(db, () => {
      if (ctx.body.action === 'grant') {
        const plan = db.prepare('SELECT * FROM subscription_plans WHERE id = ?').get(intParam(ctx.body.plan, 0, 0, 1e9));
        if (!plan) throw new HttpError(400, 'Багц олдсонгүй.');
        const s = extendSubscription(db, { userId: id, planId: plan.id, months: plan.months, source: 'admin_grant', now: ctx.now() });
        P.audit(db, ctx.now(), ctx.user.id, 'vip.grant', 'user', id, reason, { months: plan.months, endsAt: s.endsAt });
      } else if (ctx.body.action === 'revoke') {
        const n = revokeAll(db, id, reason, ctx.now());
        P.audit(db, ctx.now(), ctx.user.id, 'vip.revoke', 'user', id, reason, { revoked: n });
      } else throw new HttpError(400, 'Буруу үйлдэл.');
    });
    back(ctx, `/admin/users/${id}`, 'success', 'Хадгаллаа.');
  }, adm);

  router.post('/admin/users/:id/status', (ctx) => {
    const id = intParam(ctx.params.id, 0, 0, 1e12);
    if (id === ctx.user.id) throw new HttpError(403, 'Өөрийн бүртгэлийг идэвхгүй болгох боломжгүй.');
    const status = ctx.body.status === 'disabled' ? 'disabled' : 'active';
    const reason = need(ctx.body.reason);
    tx(db, () => {
      if (!db.prepare('SELECT 1 FROM users WHERE id = ?').get(id)) throw new HttpError(404, 'Хэрэглэгч олдсонгүй.');
      db.prepare('UPDATE users SET status = ?, updated_at = ? WHERE id = ?').run(status, iso(ctx.now()), id);
      if (status === 'disabled') A.destroyUserSessions(db, id);
      P.audit(db, ctx.now(), ctx.user.id, `user.${status}`, 'user', id, reason, null);
    });
    back(ctx, `/admin/users/${id}`, 'success', 'Хадгаллаа.');
  }, adm);

  router.get('/admin/plans', (ctx) => {
    const plans = db.prepare('SELECT * FROM subscription_plans ORDER BY sort_order').all();
    page(ctx, '/admin/plans', 'VIP багц', html`<p class="notice-inline">Үнийг энд тохируулж, багцыг идэвхжүүлсний дараа л хэрэглэгчид худалдан авах боломжтой. Үнэ нь зөвхөн серверт хадгалагдана.</p>
      ${plans.map((p) => html`<form method="post" action="/admin/plans/${p.id}" class="form panel">${csrfInput(ctx)}<h2>${p.name} (${p.months} сар)</h2>
        <div class="field"><label for="price${p.id}">Үнэ (₮)</label><input id="price${p.id}" name="price_mnt" type="number" min="1" max="100000000" value="${p.price_mnt}" required></div>
        <div class="field check"><input id="act${p.id}" name="active" type="checkbox" ${p.active ? raw('checked') : ''}><label for="act${p.id}">Идэвхтэй</label></div>
        <div class="field"><label for="why${p.id}">Өөрчлөлтийн шалтгаан</label><input id="why${p.id}" name="reason" required minlength="5" maxlength="500"></div>
        <button class="btn btn-primary" type="submit">Хадгалах</button></form>`)}`);
  }, adm);

  router.post('/admin/plans/:id', (ctx) => {
    const id = intParam(ctx.params.id, 0, 0, 1e9);
    const price = Number(ctx.body.price_mnt);
    if (!Number.isInteger(price) || price < 1 || price > 100000000) throw new HttpError(422, 'Үнэ буруу байна.');
    const reason = need(ctx.body.reason);
    tx(db, () => {
      const old = db.prepare('SELECT * FROM subscription_plans WHERE id = ?').get(id);
      if (!old) throw new HttpError(404, 'Багц олдсонгүй.');
      const active = ctx.body.active === 'on' ? 1 : 0;
      db.prepare('UPDATE subscription_plans SET price_mnt = ?, active = ?, updated_at = ? WHERE id = ?').run(price, active, iso(ctx.now()), id);
      P.audit(db, ctx.now(), ctx.user.id, 'plan.update', 'plan', old.code, reason, { price: [old.price_mnt, price], active: [old.active, active] });
    });
    back(ctx, '/admin/plans', 'success', 'Багц шинэчлэгдлээ. Өмнө үүссэн захиалгын дүн өөрчлөгдөхгүй.');
  }, adm);

  router.get('/admin/titles', (ctx) => {
    const rows = db.prepare('SELECT * FROM title_settings ORDER BY updated_at DESC LIMIT 200').all();
    page(ctx, '/admin/titles', 'Контентын эрх', html`<p class="notice-inline">Зөвхөн лицензтэй, өөрийн эзэмшлийн, эсвэл нийтийн өмчийн (public domain) видеоны https холбоосыг оруулна. Мэдээллийн API нь киног үзүүлэх эрх олгодоггүй.</p>
      <form method="post" action="/admin/titles" class="form panel">${csrfInput(ctx)}
        <div class="field"><label for="title_id">Контентын ID</label><input id="title_id" name="title_id" required maxlength="64" pattern="[A-Za-z0-9_\\-]+"></div>
        <div class="field"><label for="video_url">Видео URL (https, хоосон бол устгана)</label><input id="video_url" name="video_url" maxlength="500"></div>
        <div class="field"><label for="subtitle_url">Хадмал (.vtt) URL</label><input id="subtitle_url" name="subtitle_url" maxlength="500"></div>
        <div class="field check"><input id="vip_only" name="vip_only" type="checkbox"><label for="vip_only">Зөвхөн VIP</label></div>
        <div class="field"><label for="t_reason">Шалтгаан / эрхийн эх сурвалж</label><input id="t_reason" name="reason" required minlength="5" maxlength="500"></div>
        <button class="btn btn-primary" type="submit">Хадгалах</button></form>
      <ul>${rows.map((r) => html`<li><code>${r.title_id}</code> · ${r.video_url ? 'эх сурвалжтай' : 'эх сурвалжгүй'} · ${r.vip_only ? 'VIP' : 'нээлттэй'}</li>`)}</ul>`);
  }, adm);

  function cleanUrl(v, label) {
    const s = String(v || '').trim();
    if (!s) return null;
    let u;
    try { u = new URL(s); } catch { throw new HttpError(422, `${label} буруу байна.`); }
    if (!(u.protocol === 'https:' || (!config.isProd && u.protocol === 'http:'))) throw new HttpError(422, `${label} https байх ёстой.`);
    return u.toString();
  }

  router.post('/admin/titles', async (ctx) => {
    const id = String(ctx.body.title_id || '').trim();
    if (!/^[A-Za-z0-9_-]{1,64}$/.test(id)) throw new HttpError(422, 'Контентын ID буруу байна.');
    const reason = need(ctx.body.reason);
    if (!(await catalog.get(id))) throw new HttpError(404, 'Ийм ID-тай контент каталогоос олдсонгүй.');
    const video = cleanUrl(ctx.body.video_url, 'Видео URL');
    const sub = cleanUrl(ctx.body.subtitle_url, 'Хадмал URL');
    const vip = ctx.body.vip_only === 'on' ? 1 : 0;
    tx(db, () => {
      db.prepare(`INSERT INTO title_settings (title_id, video_url, subtitle_url, vip_only, updated_at) VALUES (?,?,?,?,?)
        ON CONFLICT(title_id) DO UPDATE SET video_url = excluded.video_url, subtitle_url = excluded.subtitle_url, vip_only = excluded.vip_only, updated_at = excluded.updated_at`)
        .run(id, video, sub, vip, iso(ctx.now()));
      P.audit(db, ctx.now(), ctx.user.id, 'title.update', 'title', id, reason, { hasVideo: !!video, vipOnly: !!vip });
    });
    back(ctx, '/admin/titles', 'success', 'Хадгаллаа.');
  }, adm);

  router.get('/admin/audit', (ctx) => {
    const rows = db.prepare('SELECT l.*, u.username FROM admin_audit_logs l JOIN users u ON u.id = l.admin_id ORDER BY l.id DESC LIMIT 200').all();
    page(ctx, '/admin/audit', 'Аудитын бүртгэл', html`<div class="table-wrap"><table><thead><tr><th>Цаг</th><th>Админ</th><th>Үйлдэл</th><th>Объект</th><th>Шалтгаан</th></tr></thead><tbody>
      ${rows.map((r) => html`<tr><td>${fmtDateTime(r.created_at)}</td><td>${r.username}</td><td>${r.action}</td><td>${r.target_type}:${r.target_id}</td><td>${r.reason || ''}</td></tr>`)}</tbody></table></div>`);
  }, adm);
};
