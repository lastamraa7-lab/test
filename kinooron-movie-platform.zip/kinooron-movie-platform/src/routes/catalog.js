'use strict';
const { html, raw, esc } = require('../views/html');
const { layout, csrfInput, posterCard, row, pager, label, GENRES, fmtDate } = require('../views/layout');
const { HttpError, iso, intParam } = require('../util');

const ID_RE = /^[A-Za-z0-9_-]{1,64}$/;

module.exports = function register(app) {
  const { router, db, catalog } = app;

  /** Attach rights data (VIP-only, playable) from the admin-managed table. */
  function decorate(items) {
    if (!items.length) return items;
    const ids = items.map((m) => m.id);
    const rows = db.prepare(`SELECT title_id, vip_only, video_url FROM title_settings WHERE title_id IN (${ids.map(() => '?').join(',')})`).all(...ids);
    const by = new Map(rows.map((r) => [r.title_id, r]));
    for (const m of items) { const s = by.get(m.id); m.vip = !!(s && s.vip_only); m.playable = !!(s && s.video_url); }
    return items;
  }

  const unavailable = (ctx) => ctx.error(503, 'Киноны мэдээллийн эх сурвалж түр хугацаанд боломжгүй байна. Түр хүлээгээд дахин оролдоно уу.');
  async function guard(ctx, fn) {
    try { return await fn(); } catch (e) {
      if (e && e.kind) { ctx.log('catalog_error', { kind: e.kind }); return unavailable(ctx); }
      throw e;
    }
  }

  async function continueWatching(ctx) {
    const rows = db.prepare('SELECT * FROM viewing_history WHERE user_id = ? AND position_seconds > 10 AND (duration_seconds = 0 OR position_seconds < duration_seconds * 0.95) ORDER BY updated_at DESC LIMIT 12').all(ctx.user.id);
    const out = [];
    for (const h of rows) {
      const t = await catalog.get(h.title_id).catch(() => null);
      if (t) out.push({ t, h });
    }
    return out;
  }

  async function recommendations(ctx) {
    const ids = db.prepare('SELECT title_id FROM user_watchlists WHERE user_id = ? UNION SELECT title_id FROM viewing_history WHERE user_id = ? LIMIT 10').all(ctx.user.id, ctx.user.id).map((r) => r.title_id);
    if (!ids.length) return [];
    const counts = {};
    for (const id of ids) {
      const t = await catalog.get(id).catch(() => null);
      for (const g of (t && t.genres) || []) counts[g] = (counts[g] || 0) + 1;
    }
    const top = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
    if (!top) return [];
    const r = await catalog.list({ genre: top[0], sort: 'popularity', pageSize: 18 });
    return r.items.filter((m) => !ids.includes(m.id)).slice(0, 12);
  }

  router.get('/', (ctx) => guard(ctx, async () => {
    const home = await catalog.home();
    const all = home.rows.flatMap((r) => r.items).concat(home.hero ? [home.hero] : []);
    decorate(all);
    const h = home.hero;
    let cw = []; let rec = [];
    if (ctx.user) { cw = await continueWatching(ctx); rec = decorate(await recommendations(ctx).catch(() => [])); }
    const body = html`
      ${h ? html`<section class="hero" aria-label="Онцлох">
        <img class="hero-bg" src="${h.backdropUrl || h.posterUrl || '/img/no-poster.svg'}" alt="" fetchpriority="high">
        <div class="hero-shade"></div>
        <div class="hero-body">
          <h1>${h.title}</h1>
          <p class="meta">${[h.year, h.type === 'series' ? 'Цуврал' : 'Кино', ...(h.genres || []).slice(0, 3).map(label)].filter(Boolean).join(' · ')}${h.rating ? ` · ★ ${h.rating}` : ''}</p>
          <p class="synopsis">${h.synopsis}</p>
          <div class="actions">
            ${h.playable ? html`<a class="btn btn-primary" href="/watch/${encodeURIComponent(h.id)}">Үзэх</a>` : ''}
            <a class="btn ${h.playable ? 'btn-ghost' : 'btn-primary'}" href="/title/${encodeURIComponent(h.id)}">Дэлгэрэнгүй</a>
            ${ctx.user
              ? html`<form method="post" action="/title/${encodeURIComponent(h.id)}/list" class="inline">${csrfInput(ctx)}<input type="hidden" name="kind" value="watchlist"><input type="hidden" name="next" value="/"><button class="btn btn-ghost" type="submit">Миний жагсаалтад нэмэх</button></form>`
              : html`<a class="btn btn-ghost" href="/login?next=/">Жагсаалтад нэмэх</a>`}
          </div>
        </div></section>` : ''}
      ${cw.length ? html`<section class="shelf" aria-label="Үргэлжлүүлэн үзэх"><div class="shelf-head"><h2>Үргэлжлүүлэн үзэх</h2></div>
        <div class="shelf-row">${cw.map(({ t, h: hist }) => html`<a class="card" href="/watch/${encodeURIComponent(t.id)}"><div class="poster"><img src="${t.posterUrl || '/img/no-poster.svg'}" alt="${t.title} — постер" width="300" height="450" loading="lazy"></div>
          <div class="card-meta"><span class="card-title">${t.title}</span><progress max="${hist.duration_seconds || 100}" value="${hist.duration_seconds ? hist.position_seconds : 0}"></progress></div></a>`)}</div></section>` : ''}
      ${rec.length ? row('Танд санал болгох', rec) : ''}
      ${home.rows.map((r) => row(r.title, r.items, r.genre ? `/browse?genre=${r.genre}` : null))}`;
    ctx.html(layout(ctx, { title: '', body, bodyClass: 'page-home' }));
  }));

  function buildQuery(base, extra) {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries({ ...base, ...extra })) if (v !== '' && v !== undefined && v !== null && v !== 0) p.set(k, v);
    const s = p.toString();
    return `/browse${s ? `?${s}` : ''}`;
  }

  router.get('/browse', (ctx) => guard(ctx, async () => {
    const q = String(ctx.query.q || '').slice(0, 80);
    const f = {
      q,
      genre: GENRES[ctx.query.genre] ? ctx.query.genre : '',
      type: ['movie', 'series'].includes(ctx.query.type) ? ctx.query.type : '',
      year: /^\d{4}$/.test(ctx.query.year || '') ? ctx.query.year : '',
      rating: [5, 6, 7, 8].includes(Number(ctx.query.rating)) ? Number(ctx.query.rating) : 0,
      language: /^[a-z]{2}$/.test(ctx.query.language || '') ? ctx.query.language : '',
      sort: ['popularity', 'newest', 'rating'].includes(ctx.query.sort) ? ctx.query.sort : 'popularity',
    };
    const page = intParam(ctx.query.page, 1, 1, 500);
    const [res, facets] = await Promise.all([catalog.list({ ...f, page, pageSize: 24 }), catalog.facets()]);
    decorate(res.items);
    const sel = (name, labelText, options, cur) => html`<label class="filter"><span>${labelText}</span><select name="${name}">${options.map(([v, t]) => html`<option value="${v}" ${String(v) === String(cur) ? raw('selected') : ''}>${t}</option>`)}</select></label>`;
    const body = html`<h1>${q ? `«${q}» хайлтын үр дүн` : 'Бүх контент'}</h1>
      <form class="filters" method="get" action="/browse">
        <input type="hidden" name="q" value="${q}">
        ${sel('genre', 'Жанр', [['', 'Бүгд'], ...Object.entries(GENRES)], f.genre)}
        ${sel('type', 'Төрөл', [['', 'Бүгд'], ['movie', 'Кино'], ['series', 'Цуврал']], f.type)}
        ${sel('year', 'Он', [['', 'Бүгд'], ...facets.years.map((y) => [y, y])], f.year)}
        ${facets.languages.length > 1 ? sel('language', 'Хэл', [['', 'Бүгд'], ...facets.languages.map((l) => [l, l.toUpperCase()])], f.language) : ''}
        ${sel('rating', 'Үнэлгээ', [[0, 'Бүгд'], [5, '5+'], [6, '6+'], [7, '7+'], [8, '8+']], f.rating)}
        ${sel('sort', 'Эрэмбэ', [['popularity', 'Алдартай'], ['newest', 'Шинэ'], ['rating', 'Үнэлгээ']], f.sort)}
        <button class="btn btn-primary" type="submit">Шүүх</button>
        <a class="btn btn-ghost" href="/browse">Цэвэрлэх</a>
      </form>
      <p class="muted" aria-live="polite">${res.total} үр дүн</p>
      ${res.items.length
        ? html`<div class="grid">${res.items.map((m) => posterCard(m))}</div>${pager(res, (p) => buildQuery(f, { page: p }))}`
        : html`<div class="empty"><h2>Үр дүн олдсонгүй</h2><p>Хайлтын үгээ өөрчлөх эсвэл шүүлтүүрээ цэвэрлээд үзнэ үү.</p><a class="btn btn-primary" href="/browse">Шүүлтүүр цэвэрлэх</a></div>`}`;
    ctx.html(layout(ctx, { title: q ? `Хайлт: ${q}` : 'Бүх контент', body }));
  }));

  router.get('/api/search', async (ctx) => {
    ctx.limit(`search:${ctx.ip}`, 120, 60000);
    const q = String(ctx.query.q || '').trim().slice(0, 80);
    if (q.length < 2) return ctx.json({ items: [] });
    try {
      const r = await catalog.list({ q, pageSize: 6 });
      return ctx.json({ items: r.items.slice(0, 6).map((m) => ({ id: m.id, title: m.title, year: m.year, type: m.type })) });
    } catch (e) {
      if (e && e.kind) return ctx.json({ items: [], error: 'unavailable' }, 503);
      throw e;
    }
  });

  function access(ctx, id) {
    const s = db.prepare('SELECT * FROM title_settings WHERE title_id = ?').get(id);
    const hasSource = !!(s && s.video_url);
    const vipOnly = !!(s && s.vip_only);
    const isVip = !!(ctx.vip && ctx.vip.active);
    return { s, hasSource, vipOnly, isVip, canWatch: hasSource && (!vipOnly || isVip) };
  }

  router.get('/title/:id', (ctx) => guard(ctx, async () => {
    if (!ID_RE.test(ctx.params.id)) throw new HttpError(404, 'Контент олдсонгүй.');
    const t = await catalog.get(ctx.params.id);
    if (!t) throw new HttpError(404, 'Контент олдсонгүй.');
    decorate([t, ...(t.similar || [])]);
    const a = access(ctx, t.id);
    const lists = ctx.user ? new Set(db.prepare('SELECT kind FROM user_watchlists WHERE user_id = ? AND title_id = ?').all(ctx.user.id, t.id).map((r) => r.kind)) : new Set();
    const listBtn = (kind, on, off) => (ctx.user
      ? html`<form method="post" action="/title/${encodeURIComponent(t.id)}/list" class="inline">${csrfInput(ctx)}<input type="hidden" name="kind" value="${kind}"><button class="btn btn-ghost" type="submit" aria-pressed="${lists.has(kind)}">${lists.has(kind) ? on : off}</button></form>`
      : html`<a class="btn btn-ghost" href="/login?next=${encodeURIComponent(`/title/${t.id}`)}">${off}</a>`);
    const body = html`<article class="detail">
      <div class="detail-backdrop"><img src="${t.backdropUrl || t.posterUrl || '/img/no-poster.svg'}" alt="" loading="eager"><div class="hero-shade"></div></div>
      <div class="detail-main">
        <img class="detail-poster" src="${t.posterUrl || '/img/no-poster.svg'}" alt="${t.title} — постер" width="300" height="450">
        <div>
          <h1>${t.title} ${a.vipOnly ? html`<span class="badge badge-vip">VIP</span>` : ''}</h1>
          <p class="meta">${[t.year, t.type === 'series' ? 'Цуврал' : 'Кино', t.runtime ? `${t.runtime} мин` : null, t.release_date ? `Нээлт: ${fmtDate(t.release_date)}` : null].filter(Boolean).join(' · ')}${t.rating ? ` · ★ ${t.rating}` : ''}</p>
          <p class="chips">${(t.genres || []).map((g) => html`<a class="chip" href="/browse?genre=${encodeURIComponent(g)}">${label(g)}</a>`)}</p>
          <p class="synopsis">${t.synopsis || 'Тайлбар одоогоор байхгүй байна.'}</p>
          <div class="actions">
            ${a.canWatch ? html`<a class="btn btn-primary" href="/watch/${encodeURIComponent(t.id)}">Үзэх</a>` : ''}
            ${a.hasSource && a.vipOnly && !a.isVip ? html`<a class="btn btn-primary" href="/vip">VIP эрх авч үзэх</a>` : ''}
            ${t.trailer_url ? html`<a class="btn btn-ghost" href="${t.trailer_url}" target="_blank" rel="noopener noreferrer">Трейлер</a>` : ''}
            ${listBtn('watchlist', '✓ Миний жагсаалтад байна', '+ Миний жагсаалт')}
            ${listBtn('favorite', '♥ Дуртай', '♡ Дуртай')}
          </div>
          ${!a.hasSource ? html`<p class="notice-inline">Энэ контентын үзэх зөвшөөрөлтэй эх сурвалж одоогоор холбогдоогүй байна. Мэдээлэл нь зөвхөн танилцуулга юм.</p>` : ''}
          <dl class="facts">
            ${t.director ? html`<dt>Найруулагч</dt><dd>${t.director}</dd>` : ''}
            ${t.cast && t.cast.length ? html`<dt>Жүжигчид</dt><dd>${t.cast.join(', ')}</dd>` : ''}
            ${t.production && t.production.length ? html`<dt>Продакшн</dt><dd>${t.production.join(', ')}</dd>` : ''}
          </dl>
        </div>
      </div>
      ${t.similar && t.similar.length ? row('Төстэй контент', t.similar) : ''}
    </article>`;
    ctx.html(layout(ctx, { title: t.title, body, description: t.synopsis }));
  }));

  router.post('/title/:id/list', (ctx) => guard(ctx, async () => {
    const kind = ctx.body.kind;
    if (!['watchlist', 'favorite'].includes(kind) || !ID_RE.test(ctx.params.id)) throw new HttpError(400, 'Буруу хүсэлт.');
    const t = await catalog.get(ctx.params.id);
    if (!t) throw new HttpError(404, 'Контент олдсонгүй.');
    const del = db.prepare('DELETE FROM user_watchlists WHERE user_id = ? AND title_id = ? AND kind = ?').run(ctx.user.id, t.id, kind);
    if (del.changes === 0) db.prepare('INSERT INTO user_watchlists (user_id, title_id, kind, created_at) VALUES (?,?,?,?)').run(ctx.user.id, t.id, kind, iso(ctx.now()));
    const next = typeof ctx.body.next === 'string' && ctx.body.next.startsWith('/') && !ctx.body.next.startsWith('//') ? ctx.body.next : `/title/${encodeURIComponent(t.id)}`;
    ctx.redirect(next, ['success', del.changes ? 'Жагсаалтаас хаслаа.' : 'Жагсаалтад нэмлээ.']);
  }), { auth: 'user' });

  router.get('/watch/:id', (ctx) => guard(ctx, async () => {
    if (!ID_RE.test(ctx.params.id)) throw new HttpError(404, 'Контент олдсонгүй.');
    const t = await catalog.get(ctx.params.id);
    if (!t) throw new HttpError(404, 'Контент олдсонгүй.');
    const a = access(ctx, t.id);
    if (a.hasSource && a.vipOnly && !a.isVip) return ctx.redirect(ctx.user ? '/vip' : `/login?next=${encodeURIComponent(`/watch/${t.id}`)}`, ['info', 'Энэ контент зөвхөн VIP эрхтэй хэрэглэгчдэд нээлттэй.']);
    let start = 0;
    if (ctx.user && a.canWatch) {
      const h = db.prepare('SELECT position_seconds, duration_seconds FROM viewing_history WHERE user_id = ? AND title_id = ?').get(ctx.user.id, t.id);
      if (h && h.position_seconds > 10 && (!h.duration_seconds || h.position_seconds < h.duration_seconds * 0.95)) start = h.position_seconds;
    }
    const body = html`<section class="watch"><h1>${t.title}</h1>
      ${a.canWatch
        ? html`<video id="player" class="player" controls preload="metadata" playsinline data-title-id="${t.id}" data-start="${start}">
            <source src="${a.s.video_url}">
            ${a.s.subtitle_url ? html`<track kind="subtitles" src="${a.s.subtitle_url}" srclang="mn" label="Монгол">` : ''}
            Таны хөтөч видео тоглуулахыг дэмжихгүй байна.</video>
          <p id="player-error" class="notice-inline" role="alert" hidden>Видеог ачаалж чадсангүй. Холболтоо шалгаад дахин оролдоно уу.</p>`
        : html`<div class="empty"><h2>Үзэх эх сурвалж байхгүй</h2><p>Энэ контентод одоогоор зөвшөөрөлтэй видео холбогдоогүй байна.</p></div>`}
      <p><a href="/title/${encodeURIComponent(t.id)}">← Дэлгэрэнгүй рүү буцах</a></p></section>`;
    ctx.html(layout(ctx, { title: t.title, body }));
  }));

  router.post('/api/progress', (ctx) => {
    const b = ctx.body || {};
    if (typeof b.titleId !== 'string' || !ID_RE.test(b.titleId)) throw new HttpError(400, 'Буруу хүсэлт.');
    ctx.limit(`progress:${ctx.user.id}`, 240, 60000);
    const a = access(ctx, b.titleId);
    if (!a.canWatch) throw new HttpError(403, 'Хандах эрхгүй.');
    const pos = intParam(b.position, 0, 0, 86400);
    const dur = intParam(b.duration, 0, 0, 86400);
    db.prepare(`INSERT INTO viewing_history (user_id, title_id, position_seconds, duration_seconds, updated_at) VALUES (?,?,?,?,?)
      ON CONFLICT(user_id, title_id) DO UPDATE SET position_seconds = excluded.position_seconds, duration_seconds = excluded.duration_seconds, updated_at = excluded.updated_at`)
      .run(ctx.user.id, b.titleId, pos, dur, iso(ctx.now()));
    ctx.json({ ok: true });
  }, { auth: 'user' });

  // Deterministic placeholder art for SAMPLE titles only (never shown as real artwork).
  router.get('/poster/:file', (ctx) => {
    const id = ctx.params.file.replace(/\.svg$/, '');
    if (!ID_RE.test(id)) throw new HttpError(404, 'Олдсонгүй.');
    return catalog.get(id).then((t) => {
      if (!t || catalog.name !== 'mock') throw new HttpError(404, 'Олдсонгүй.');
      const wide = ctx.query.w === 'backdrop';
      const W = wide ? 1280 : 300; const Hh = wide ? 720 : 450;
      const words = t.title.split(' ');
      const lines = [];
      let cur = '';
      for (const w of words) { if ((`${cur} ${w}`).trim().length > (wide ? 28 : 13) && cur) { lines.push(cur); cur = w; } else cur = `${cur} ${w}`.trim(); }
      if (cur) lines.push(cur);
      const fs = wide ? 54 : 26;
      const y0 = Hh / 2 - ((lines.length - 1) * fs * 0.6);
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${Hh}" width="${W}" height="${Hh}" role="img" aria-label="${esc(t.title)}">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl(${t.hue},22%,24%)"/><stop offset="1" stop-color="hsl(${(t.hue + 40) % 360},20%,9%)"/></linearGradient></defs>
<rect width="${W}" height="${Hh}" fill="url(#g)"/>
${lines.map((l, i) => `<text x="${W / 2}" y="${y0 + i * fs * 1.25}" fill="#e6e3dc" font-family="system-ui,sans-serif" font-size="${fs}" font-weight="600" text-anchor="middle">${esc(l)}</text>`).join('')}
<text x="${W / 2}" y="${Hh - 18}" fill="#b9b6ad" font-family="system-ui,sans-serif" font-size="${wide ? 20 : 11}" text-anchor="middle">ЖИШЭЭ ПОСТЕР · бодит зураг биш</text></svg>`;
      ctx.bytes(Buffer.from(svg), 'image/svg+xml', 200, { 'cache-control': 'public, max-age=86400' });
    });
  });
};
