'use strict';
const { randomToken, sha256 } = require('./security');
const { iso } = require('./util');

function createSession(db, config, userId = null) {
  const token = randomToken(32);
  const csrf = randomToken(24);
  const now = config.now();
  const expires = new Date(now.getTime() + config.sessionTtlDays * 86400000);
  db.prepare('INSERT INTO sessions (token_hash, user_id, csrf_token, created_at, expires_at, last_seen_at) VALUES (?,?,?,?,?,?)')
    .run(sha256(token), userId, csrf, iso(now), iso(expires), iso(now));
  return { token, csrf, expires };
}

/** Returns {hash, csrf, user, flash} or null. Expired sessions are removed; disabled users are signed out. */
function loadSession(db, config, token) {
  if (!token || typeof token !== 'string' || token.length > 100) return null;
  const hash = sha256(token);
  const s = db.prepare('SELECT * FROM sessions WHERE token_hash = ?').get(hash);
  if (!s) return null;
  if (s.expires_at <= iso(config.now())) {
    db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(hash);
    return null;
  }
  let user = null;
  if (s.user_id) {
    user = db.prepare('SELECT id, public_id, username, email, email_verified_at, role, status, created_at FROM users WHERE id = ?').get(s.user_id);
    if (!user || user.status !== 'active') {
      db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(hash);
      return null;
    }
  }
  let flash = null;
  if (s.flash) {
    try { flash = JSON.parse(s.flash); } catch { flash = null; }
    db.prepare('UPDATE sessions SET flash = NULL WHERE token_hash = ?').run(hash);
  }
  return { hash, csrf: s.csrf_token, user, flash };
}

const destroySession = (db, hash) => db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(hash);
const destroyUserSessions = (db, userId, exceptHash = '') =>
  db.prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash != ?').run(userId, exceptHash);
const setFlash = (db, hash, type, text) =>
  db.prepare('UPDATE sessions SET flash = ? WHERE token_hash = ?').run(JSON.stringify({ type, text }), hash);

function purgeExpired(db, config) {
  const now = iso(config.now());
  db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(now);
  db.prepare('DELETE FROM email_tokens WHERE expires_at <= ? OR used_at IS NOT NULL').run(now);
}

// Email verification / password reset tokens (stored hashed, single use).
function createEmailToken(db, config, userId, kind, ttlMinutes) {
  const token = randomToken(32);
  const now = config.now();
  db.prepare('UPDATE email_tokens SET used_at = ? WHERE user_id = ? AND kind = ? AND used_at IS NULL').run(iso(now), userId, kind);
  db.prepare('INSERT INTO email_tokens (user_id, kind, token_hash, expires_at, created_at) VALUES (?,?,?,?,?)')
    .run(userId, kind, sha256(token), iso(new Date(now.getTime() + ttlMinutes * 60000)), iso(now));
  return token;
}

function peekEmailToken(db, config, token, kind) {
  if (!token || typeof token !== 'string' || token.length > 100) return null;
  return db.prepare('SELECT * FROM email_tokens WHERE token_hash = ? AND kind = ? AND used_at IS NULL AND expires_at > ?')
    .get(sha256(token), kind, iso(config.now())) || null;
}

const consumeEmailToken = (db, config, id) =>
  db.prepare('UPDATE email_tokens SET used_at = ? WHERE id = ? AND used_at IS NULL').run(iso(config.now()), id).changes === 1;

module.exports = { createSession, loadSession, destroySession, destroyUserSessions, setFlash, purgeExpired, createEmailToken, peekEmailToken, consumeEmailToken };
