'use strict';
const { iso, addMonths } = require('./util');
const { tx } = require('./db');

/** VIP is computed from timestamps on every read, so expiry needs no background job. */
function getVipStatus(db, userId, now) {
  const t = iso(now);
  // Active if some unrevoked subscription covers `now`. The displayed expiry is the end of the whole
  // chain: renewals are queued back-to-back (see extendSubscription), so MAX(ends_at) is the real expiry.
  const cur = db.prepare(
    `SELECT MIN(starts_at) AS starts_at FROM subscriptions
     WHERE user_id = ? AND revoked_at IS NULL AND starts_at <= ? AND ends_at > ?`).get(userId, t, t);
  const row = cur && cur.starts_at
    ? { starts_at: cur.starts_at, ends_at: db.prepare('SELECT MAX(ends_at) AS e FROM subscriptions WHERE user_id = ? AND revoked_at IS NULL AND ends_at > ?').get(userId, t).e }
    : null;
  if (!row || !row.ends_at) {
    const last = db.prepare('SELECT MAX(ends_at) AS e FROM subscriptions WHERE user_id = ? AND revoked_at IS NULL').get(userId);
    return { active: false, endsAt: null, startsAt: null, lastEndedAt: last && last.e };
  }
  return { active: true, endsAt: row.ends_at, startsAt: row.starts_at };
}

/**
 * Renewal policy: a new subscription starts at max(now, latest unrevoked end) so renewals extend
 * the existing expiry instead of overlapping it. order_id is UNIQUE, so one paid order can only
 * ever activate once.
 */
function extendSubscription(db, { userId, planId = null, months, orderId = null, source, now }) {
  return tx(db, () => {
    const t = iso(now);
    const latest = db.prepare('SELECT MAX(ends_at) AS e FROM subscriptions WHERE user_id = ? AND revoked_at IS NULL AND ends_at > ?').get(userId, t).e;
    const start = latest && latest > t ? new Date(latest) : new Date(now);
    const end = addMonths(start, months);
    const info = db.prepare(
      'INSERT INTO subscriptions (user_id, plan_id, order_id, source, starts_at, ends_at, created_at) VALUES (?,?,?,?,?,?,?)')
      .run(userId, planId, orderId, source, iso(start), iso(end), t);
    return { id: Number(info.lastInsertRowid), startsAt: iso(start), endsAt: iso(end) };
  });
}

function revokeAll(db, userId, reason, now) {
  const t = iso(now);
  return db.prepare('UPDATE subscriptions SET revoked_at = ?, revoked_reason = ? WHERE user_id = ? AND revoked_at IS NULL AND ends_at > ?')
    .run(t, reason, userId, t).changes;
}

const listSubscriptions = (db, userId) =>
  db.prepare(`SELECT s.*, p.name AS plan_name FROM subscriptions s LEFT JOIN subscription_plans p ON p.id = s.plan_id
              WHERE s.user_id = ? ORDER BY s.created_at DESC`).all(userId);

module.exports = { getVipStatus, extendSubscription, revokeAll, listSubscriptions };
