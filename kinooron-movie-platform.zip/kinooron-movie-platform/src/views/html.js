'use strict';
// Tiny auto-escaping template tag. Every interpolated value is escaped unless wrapped by raw()
// or produced by another html`` call, so templates are XSS-safe by default.
class Raw { constructor(s) { this.s = s; } toString() { return this.s; } }
const raw = (s) => new Raw(String(s));
const MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
function esc(v) {
  if (v instanceof Raw) return v.s;
  if (Array.isArray(v)) return v.map(esc).join('');
  if (v === null || v === undefined || v === false) return '';
  return String(v).replace(/[&<>"']/g, (c) => MAP[c]);
}
function html(strings, ...vals) {
  let out = strings[0];
  for (let i = 0; i < vals.length; i += 1) out += esc(vals[i]) + strings[i + 1];
  return new Raw(out);
}
module.exports = { html, raw, esc, Raw };
