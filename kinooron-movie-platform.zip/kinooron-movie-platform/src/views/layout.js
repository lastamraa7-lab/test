'use strict';
const { html, raw } = require('./html');
const { label, GENRES } = require('../catalog/genres');
const { fmtMnt, fmtDate, fmtDateTime } = require('../util');

const csrfInput = (ctx) => html`<input type="hidden" name="_csrf" value="${ctx.csrf || ''}">`;

function layout(ctx, { title, body, bodyClass = '', description = '' }) {
  const { user, config, catalog } = ctx;
  const vipBadge = ctx.vip && ctx.vip.active ? html`<span class="badge badge-vip" title="VIP хүчинтэй: ${fmtDate(ctx.vip.endsAt)} хүртэл">VIP</span>` : '';
  return html`<!doctype html>
<html lang="mn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${title ? `${title} · ` : ''}${config.siteName}</title>
<meta name="description" content="${description || 'Монгол хэл дээрх кино нээлт, хайлт, VIP эрх.'}">
<meta name="color-scheme" content="dark">
<meta name="csrf-token" content="${ctx.csrf || ''}">
<link rel="stylesheet" href="/css/app.css">
<script src="/js/app.js" defer></script>
</head>
<body class="${bodyClass}">
<a class="skip-link" href="#main">Агуулга руу очих</a>
<header class="site-header">
  <div class="container header-inner">
    <a class="logo" href="/" aria-label="${config.siteName} — нүүр хуудас">${config.siteName}</a>
    <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="site-nav">Цэс</button>
    <nav id="site-nav" class="site-nav" aria-label="Үндсэн цэс">
      <a href="/">Нүүр</a>
      <a href="/browse">Бүх контент</a>
      <a href="/browse?type=movie">Кино</a>
      <a href="/browse?type=series">Цуврал</a>
      <a href="/vip" class="nav-vip">VIP</a>
    </nav>
    <form class="search" role="search" action="/browse" method="get" autocomplete="off">
      <label class="sr-only" for="q">Хайх</label>
      <input id="q" name="q" type="search" placeholder="Кино, жанраар хайх" maxlength="80" value="${ctx.query && ctx.query.q ? ctx.query.q : ''}" aria-controls="suggest" aria-autocomplete="list">
      <button type="button" class="search-clear" hidden aria-label="Хайлтыг цэвэрлэх">×</button>
      <button type="submit" class="btn btn-ghost">Хайх</button>
      <ul id="suggest" class="suggest" hidden></ul>
    </form>
    <div class="account-menu">
      ${user
        ? html`${vipBadge}<a href="/account" class="btn btn-ghost">${user.username}</a>
          ${user.role === 'admin' ? html`<a href="/admin" class="btn btn-ghost">Админ</a>` : ''}
          <form method="post" action="/logout" class="inline">${csrfInput(ctx)}<button class="btn btn-ghost" type="submit">Гарах</button></form>`
        : html`<a href="/login" class="btn btn-ghost">Нэвтрэх</a><a href="/register" class="btn btn-primary">Бүртгүүлэх</a>`}
    </div>
  </div>
</header>
${catalog.isSample ? html`<div class="notice notice-sample" role="note"><div class="container">Туршилтын жишээ өгөгдөл: энэ сайтад харагдаж буй киноны нэр, үнэлгээ, тайлбар бодит биш (TMDB түлхүүр тохируулаагүй байна).</div></div>` : ''}
<main id="main" class="container" tabindex="-1">
  ${ctx.flash ? html`<div class="flash flash-${ctx.flash.type || 'info'}" role="status">${ctx.flash.text}</div>` : ''}
  ${body}
</main>
<footer class="site-footer">
  <div class="container footer-inner">
    <nav aria-label="Хөл цэс">
      <a href="/terms">Үйлчилгээний нөхцөл</a>
      <a href="/privacy">Нууцлалын бодлого</a>
      <a href="/help">Тусламж</a>
      <a href="/contact">Холбоо барих</a>
    </nav>
    <p class="muted">© ${config.siteName}. ${catalog.attribution || ''}</p>
  </div>
</footer>
</body>
</html>`;
}

function posterCard(m, { eager = false } = {}) {
  const src = m.posterUrl || '/img/no-poster.svg';
  return html`<a class="card" href="/title/${encodeURIComponent(m.id)}">
    <div class="poster"><img src="${src}" alt="${m.title} — постер" width="300" height="450" loading="${eager ? 'eager' : 'lazy'}" decoding="async">
      ${m.vip ? html`<span class="badge badge-vip card-badge">VIP</span>` : ''}
    </div>
    <div class="card-meta"><span class="card-title">${m.title}</span>
      <span class="muted">${m.year || ''}${m.type === 'series' ? ' · Цуврал' : ''}${m.rating ? ` · ★ ${m.rating}` : ''}</span></div>
  </a>`;
}

function row(title, items, moreHref) {
  if (!items.length) return '';
  return html`<section class="shelf" aria-label="${title}">
    <div class="shelf-head"><h2>${title}</h2>${moreHref ? html`<a href="${moreHref}">Бүгдийг харах</a>` : ''}</div>
    <div class="shelf-row">${items.map((m) => posterCard(m))}</div>
  </section>`;
}

function pager(info, hrefFor) {
  if (info.pages <= 1) return '';
  const link = (p, text, cur) => (cur
    ? html`<span class="page current" aria-current="page">${text}</span>`
    : html`<a class="page" href="${hrefFor(p)}">${text}</a>`);
  return html`<nav class="pager" aria-label="Хуудаслалт">
    ${info.page > 1 ? link(info.page - 1, '‹ Өмнөх') : ''}
    <span class="muted">${info.page} / ${info.pages}</span>
    ${info.page < info.pages ? link(info.page + 1, 'Дараах ›') : ''}
  </nav>`;
}

function field({ id, label: text, type = 'text', value = '', required = true, autocomplete = '', help = '', attrs = {} }) {
  const extra = Object.entries(attrs).map(([k, v]) => `${k}="${String(v).replace(/"/g, '&quot;')}"`).join(' ');
  return html`<div class="field"><label for="${id}">${text}</label>
    <input id="${id}" name="${id}" type="${type}" value="${value}" ${required ? raw('required') : ''} ${autocomplete ? raw(`autocomplete="${autocomplete}"`) : ''} ${raw(extra)}>
    ${help ? html`<small class="muted">${help}</small>` : ''}</div>`;
}

function statusLabel(s) {
  return ({ CREATED: 'Төлбөр хүлээгдэж байна', PENDING_REVIEW: 'Шалгагдаж байна', PAID: 'Төлөгдсөн', REJECTED: 'Татгалзсан', EXPIRED: 'Хугацаа дууссан', FAILED: 'Амжилтгүй', REFUNDED: 'Буцаагдсан' })[s] || s;
}

module.exports = { layout, csrfInput, posterCard, row, pager, field, statusLabel, label, GENRES, fmtMnt, fmtDate, fmtDateTime };
