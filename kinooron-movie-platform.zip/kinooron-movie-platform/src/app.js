'use strict';
const http = require('node:http');
const fs = require('node:fs');
const { load } = require('./config');
const { openDb, migrate } = require('./db');
const { createCatalog } = require('./catalog');
const { createRegistry } = require('./payments/providers');
const { createMailer } = require('./mailer');
const { RateLimiter, sha256 } = require('./security');
const auth = require('./auth');
const { getVipStatus } = require('./subscriptions');
const { HttpError, iso } = require('./util');
const H = require('./http');
const { html } = require('./views/html');
const { layout } = require('./views/layout');

const MAX_FORM = 64 * 1024;
const MAX_UPLOAD = 3 * 1024 * 1024;

function createApp(envOverrides = {}, direct = {}) {
  const config = load(envOverrides, direct);
  const db = openDb(config.dbPath);
  migrate(db, config.migrationsDir);
  fs.mkdirSync(config.uploadDir, { recursive: true });

  const catalog = createCatalog(config, direct);
  catalog.isSample = !!catalog.isSample;
  const providers = createRegistry(config);
  const baseRegister = providers.register.bind(providers);
  providers.register = (p) => {
    if (p.name === 'test_simulated' && !config.allowTestProvider) throw new Error('Test payment provider is only available when NODE_ENV=test');
    baseRegister(p);
  };
  const mailer = createMailer(db, config);
  const limiter = new RateLimiter(() => config.now());
  const router = H.createRouter();
  const log = (type, data = {}) => { if (!config.quiet) console.log(JSON.stringify({ t: iso(config.now()), type, ...data })); };
  const cookieName = config.cookieSecure ? '__Host-sid' : 'sid';

  const app = { config, db, catalog, providers, mailer, limiter, router, log, cookieName };
  for (const name of ['auth', 'catalog', 'account', 'vip', 'admin', 'pages']) require(`./routes/${name}`)(app);

  const extraImg = catalog.name === 'tmdb' ? 'https://image.tmdb.org' : '';

  function errorPage(ctx, status, message) {
    const titles = { 400: 'Буруу хүсэлт', 401: 'Нэвтрэх шаардлагатай', 403: 'Хандах эрхгүй', 404: 'Хуудас олдсонгүй', 409: 'Зөрчил гарлаа', 413: 'Хэт том', 422: 'Мэдээлэл буруу', 429: 'Хэт олон хүсэлт', 500: 'Серверийн алдаа' };
    ctx.html(layout(ctx, { title: titles[status] || 'Алдаа', body: html`<section class="narrow"><h1>${titles[status] || 'Алдаа'}</h1><p>${message}</p><p><a class="btn btn-primary" href="/">Нүүр хуудас руу буцах</a></p></section>` }), status);
  }

  async function handle(req, res) {
    const url = new URL(req.url, 'http://localhost');
    const ip = H.clientIp(req, config);
    const headers = H.securityHeaders(config, extraImg);
    for (const [k, v] of Object.entries(headers)) res.setHeader(k, v);

    const method = req.method === 'HEAD' ? 'GET' : req.method;
    if (method === 'GET' && /^\/(css|js|img)\//.test(url.pathname) && H.serveStatic(config, url.pathname, res)) return;
    if (url.pathname === '/healthz') { res.writeHead(200, { 'content-type': 'text/plain' }); res.end('ok'); return; }

    const cookies = H.parseCookies(req.headers.cookie);
    const setCookies = [];
    const ctx = {
      req, res, url, ip, config, db, catalog, app, method,
      query: Object.fromEntries(url.searchParams), params: {}, body: {}, files: [], rawBody: null,
      session: null, user: null, vip: null, csrf: '', flash: null,
      now: () => config.now(),
      log,
    };
    ctx.sendCookie = (c) => setCookies.push(c);
    const cookieAttrs = (maxAge) => `Path=/; HttpOnly; SameSite=Lax${config.cookieSecure ? '; Secure' : ''}${maxAge !== undefined ? `; Max-Age=${maxAge}` : ''}`;
    const writeHead = (status, extra = {}) => {
      const h = { ...extra };
      if (setCookies.length) h['set-cookie'] = setCookies;
      res.writeHead(status, h);
    };
    ctx.setSession = (s, token) => {
      ctx.session = s; ctx.csrf = s.csrf; ctx.user = s.user;
      ctx.sendCookie(`${cookieName}=${encodeURIComponent(token)}; ${cookieAttrs(config.sessionTtlDays * 86400)}`);
    };
    ctx.ensureSession = () => {
      if (ctx.session) return ctx.session;
      const s = auth.createSession(db, config, null);
      ctx.setSession({ hash: sha256(s.token), csrf: s.csrf, user: null }, s.token);
      return ctx.session;
    };
    ctx.login = (userId) => {
      if (ctx.session) auth.destroySession(db, ctx.session.hash);
      const s = auth.createSession(db, config, userId);
      const user = db.prepare('SELECT id, public_id, username, email, email_verified_at, role, status, created_at FROM users WHERE id = ?').get(userId);
      ctx.setSession({ hash: sha256(s.token), csrf: s.csrf, user }, s.token);
      return s;
    };
    ctx.logout = () => {
      if (ctx.session) auth.destroySession(db, ctx.session.hash);
      ctx.session = null; ctx.user = null; ctx.csrf = '';
      ctx.sendCookie(`${cookieName}=; ${cookieAttrs(0)}`);
    };
    ctx.flashNext = (type, text) => { ctx.ensureSession(); auth.setFlash(db, ctx.session.hash, type, text); };
    ctx.limit = (key, limit, windowMs) => {
      if (!limiter.take(key, limit, windowMs)) { log('rate_limited', { key: key.split(':')[0], ip }); throw new HttpError(429, 'Хэт олон оролдлого хийлээ. Түр хүлээгээд дахин оролдоно уу.'); }
    };
    const secure = (headersExtra = {}) => ({ 'cache-control': 'no-store', ...headersExtra });
    ctx.html = (node, status = 200) => { writeHead(status, secure({ 'content-type': 'text/html; charset=utf-8' })); res.end(String(node)); };
    ctx.json = (obj, status = 200) => { writeHead(status, secure({ 'content-type': 'application/json; charset=utf-8' })); res.end(JSON.stringify(obj)); };
    ctx.text = (s, status = 200, type = 'text/plain; charset=utf-8') => { writeHead(status, secure({ 'content-type': type })); res.end(s); };
    ctx.bytes = (buf, type, status = 200, extra = {}) => { writeHead(status, secure({ 'content-type': type, 'content-length': buf.length, 'x-content-type-options': 'nosniff', ...extra })); res.end(buf); };
    ctx.redirect = (loc, flash) => { if (flash) ctx.flashNext(flash[0], flash[1]); writeHead(303, secure({ location: loc })); res.end(); };
    ctx.error = (status, msg) => errorPage(ctx, status, msg);

    try {
      const { route, params, pathMatched } = router.match(method, url.pathname);
      if (!route) { if (pathMatched) throw new HttpError(405, 'Энэ аргыг зөвшөөрөөгүй.'); throw new HttpError(404, 'Хайсан хуудас олдсонгүй.'); }
      ctx.params = params;

      const s = auth.loadSession(db, config, cookies[cookieName]);
      if (s) { ctx.session = s; ctx.user = s.user; ctx.csrf = s.csrf; ctx.flash = s.flash; }
      else if (cookies[cookieName]) ctx.sendCookie(`${cookieName}=; ${cookieAttrs(0)}`);
      if (ctx.user) ctx.vip = getVipStatus(db, ctx.user.id, config.now());

      const o = route.opts;
      if (o.auth === 'user' && !ctx.user) {
        if (method === 'GET') { ctx.redirect(`/login?next=${encodeURIComponent(url.pathname + url.search)}`, ['info', 'Эхлээд нэвтэрнэ үү.']); return; }
        throw new HttpError(401, 'Энэ үйлдлийг хийхийн тулд нэвтэрнэ үү.');
      }
      if (o.auth === 'admin' && !(ctx.user && ctx.user.role === 'admin')) throw new HttpError(404, 'Хайсан хуудас олдсонгүй.');

      if (req.method === 'POST') {
        const ctype = String(req.headers['content-type'] || '');
        if (o.raw) {
          ctx.rawBody = await H.readBody(req, MAX_FORM);
        } else if (ctype.startsWith('multipart/form-data')) {
          const m = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(ctype);
          if (!m) throw new HttpError(400, 'Буруу хүсэлт.');
          const buf = await H.readBody(req, o.maxBody || MAX_UPLOAD);
          const parsed = H.parseMultipart(buf, m[1] || m[2]);
          ctx.body = parsed.fields; ctx.files = parsed.files;
        } else if (ctype.startsWith('application/json')) {
          const buf = await H.readBody(req, MAX_FORM);
          try { ctx.body = JSON.parse(buf.toString('utf8') || '{}'); } catch { throw new HttpError(400, 'Буруу JSON.'); }
        } else {
          const buf = await H.readBody(req, MAX_FORM);
          ctx.body = Object.fromEntries(new URLSearchParams(buf.toString('utf8')));
        }
        if (o.csrf !== false) H.checkCsrf(ctx, (ctx.body && ctx.body._csrf) || req.headers['x-csrf-token']);
      }
      await route.handler(ctx);
    } catch (err) {
      if (res.headersSent) { res.end(); return; }
      const isApi = url.pathname.startsWith('/api/') || url.pathname.startsWith('/webhooks/');
      if (err instanceof HttpError) {
        if (isApi) ctx.json({ error: err.message }, err.status); else errorPage(ctx, err.status, err.message);
      } else {
        log('server_error', { path: url.pathname, message: String(err && err.message).slice(0, 200) });
        if (isApi) ctx.json({ error: 'Серверийн алдаа гарлаа.' }, 500);
        else errorPage(ctx, 500, 'Серверт алдаа гарлаа. Дахин оролдоно уу.');
      }
    }
  }

  const server = http.createServer((req, res) => {
    handle(req, res).catch(() => { try { if (!res.headersSent) res.writeHead(500); res.end(); } catch { /* socket gone */ } });
  });
  server.requestTimeout = 30000;
  server.headersTimeout = 15000;

  const sweep = setInterval(() => { try { auth.purgeExpired(db, config); } catch { /* best effort */ } }, 10 * 60 * 1000);
  sweep.unref();

  return {
    ...app,
    server,
    listen: (port = config.port) => new Promise((resolve) => server.listen(port, () => resolve(server.address().port))),
    close: () => new Promise((resolve) => { clearInterval(sweep); server.close(() => { try { db.close(); } catch { /* already closed */ } resolve(); }); server.closeAllConnections?.(); }),
  };
}

module.exports = { createApp };
